import {
  users,
  type User,
  type InsertUser,
  categories,
  type Category,
  type InsertCategory,
  products,
  type Product,
  type InsertProduct,
  orders,
  type Order,
  type InsertOrder,
  orderItems,
  type OrderItem,
  type InsertOrderItem,
  cartItems,
  type CartItem,
  type InsertCartItem,
  wishlistItems,
  type WishlistItem,
  type InsertWishlistItem
} from "@shared/schema";
import { db } from "./db";
import { eq, and, like, desc, asc } from "drizzle-orm";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Category operations
  getAllCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<Category>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Product operations
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getFeaturedProducts(limit?: number): Promise<Product[]>;
  getNewProducts(limit?: number): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Order operations
  getOrder(id: number): Promise<Order | undefined>;
  getUserOrders(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  getOrderWithItems(id: number): Promise<{order: Order, items: OrderItem[]} | undefined>;
  
  // OrderItem operations
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  
  // CartItem operations
  getUserCartItems(userId: number): Promise<CartItem[]>;
  getCartItemWithProduct(userId: number): Promise<{cartItem: CartItem, product: Product}[]>;
  getCartItem(userId: number, productId: number): Promise<CartItem | undefined>;
  createCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;
  clearCart(userId: number): Promise<boolean>;
  
  // WishlistItem operations
  getUserWishlistItems(userId: number): Promise<WishlistItem[]>;
  getWishlistItemWithProduct(userId: number): Promise<{wishlistItem: WishlistItem, product: Product}[]>;
  getWishlistItem(userId: number, productId: number): Promise<WishlistItem | undefined>;
  createWishlistItem(wishlistItem: InsertWishlistItem): Promise<WishlistItem>;
  deleteWishlistItem(id: number): Promise<boolean>;
  
  // Admin operations
  initializeAdminUser(): Promise<User>;
  initializeSampleData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize database
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash password if not already hashed
    if (!insertUser.password.startsWith("$2a$")) {
      insertUser.password = await bcrypt.hash(insertUser.password, 10);
    }
    
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async updateUser(id: number, userUpdate: Partial<User>): Promise<User | undefined> {
    // Hash password if it's being updated and not already hashed
    if (userUpdate.password && !userUpdate.password.startsWith("$2a$")) {
      userUpdate.password = await bcrypt.hash(userUpdate.password, 10);
    }
    
    const [updatedUser] = await db.update(users)
      .set(userUpdate)
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }
  
  // Category operations
  async getAllCategories(): Promise<Category[]> {
    return db.select().from(categories);
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category;
  }
  
  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }
  
  async updateCategory(id: number, categoryUpdate: Partial<Category>): Promise<Category | undefined> {
    const [updatedCategory] = await db.update(categories)
      .set(categoryUpdate)
      .where(eq(categories.id, id))
      .returning();
    
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    await db.delete(categories).where(eq(categories.id, id));
    return true;
  }
  
  // Product operations
  async getAllProducts(): Promise<Product[]> {
    return db.select().from(products);
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }
  
  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.slug, slug));
    return product;
  }
  
  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return db.select().from(products).where(eq(products.categoryId, categoryId));
  }
  
  async getFeaturedProducts(limit?: number): Promise<Product[]> {
    let query = db.select().from(products).where(eq(products.isFeatured, true));
    
    if (limit) {
      return db.select().from(products).where(eq(products.isFeatured, true)).limit(limit);
    }
    
    return query;
  }
  
  async getNewProducts(limit?: number): Promise<Product[]> {
    let query = db.select().from(products).where(eq(products.isNew, true));
    
    if (limit) {
      return db.select().from(products).where(eq(products.isNew, true)).limit(limit);
    }
    
    return query;
  }
  
  async searchProducts(query: string): Promise<Product[]> {
    const searchPattern = `%${query}%`;
    return db.select().from(products).where(
      like(products.name, searchPattern)
    );
  }
  
  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }
  
  async updateProduct(id: number, productUpdate: Partial<Product>): Promise<Product | undefined> {
    const [updatedProduct] = await db.update(products)
      .set(productUpdate)
      .where(eq(products.id, id))
      .returning();
    
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    await db.delete(products).where(eq(products.id, id));
    return true;
  }
  
  // Order operations
  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }
  
  async getUserOrders(userId: number): Promise<Order[]> {
    return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  }
  
  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }
  
  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const [updatedOrder] = await db.update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
    
    return updatedOrder;
  }
  
  async getOrderWithItems(id: number): Promise<{order: Order, items: OrderItem[]} | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return undefined;
    
    const items = await this.getOrderItems(id);
    return { order, items };
  }
  
  // OrderItem operations
  async createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem> {
    const [newOrderItem] = await db.insert(orderItems).values(orderItem).returning();
    return newOrderItem;
  }
  
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }
  
  // CartItem operations
  async getUserCartItems(userId: number): Promise<CartItem[]> {
    return db.select().from(cartItems).where(eq(cartItems.userId, userId));
  }
  
  async getCartItemWithProduct(userId: number): Promise<{cartItem: CartItem, product: Product}[]> {
    const userCartItems = await this.getUserCartItems(userId);
    const result: {cartItem: CartItem, product: Product}[] = [];
    
    for (const cartItem of userCartItems) {
      const product = await this.getProduct(cartItem.productId);
      if (product) {
        result.push({ cartItem, product });
      }
    }
    
    return result;
  }
  
  async getCartItem(userId: number, productId: number): Promise<CartItem | undefined> {
    const [cartItem] = await db.select().from(cartItems).where(
      and(
        eq(cartItems.userId, userId),
        eq(cartItems.productId, productId)
      )
    );
    
    return cartItem;
  }
  
  async createCartItem(cartItem: InsertCartItem): Promise<CartItem> {
    const [newCartItem] = await db.insert(cartItems).values(cartItem).returning();
    return newCartItem;
  }
  
  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined> {
    const [updatedCartItem] = await db.update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    
    return updatedCartItem;
  }
  
  async deleteCartItem(id: number): Promise<boolean> {
    await db.delete(cartItems).where(eq(cartItems.id, id));
    return true;
  }
  
  async clearCart(userId: number): Promise<boolean> {
    await db.delete(cartItems).where(eq(cartItems.userId, userId));
    return true; // Return true even if no items were deleted
  }
  
  // WishlistItem operations
  async getUserWishlistItems(userId: number): Promise<WishlistItem[]> {
    return db.select().from(wishlistItems).where(eq(wishlistItems.userId, userId));
  }
  
  async getWishlistItemWithProduct(userId: number): Promise<{wishlistItem: WishlistItem, product: Product}[]> {
    const userWishlistItems = await this.getUserWishlistItems(userId);
    const result: {wishlistItem: WishlistItem, product: Product}[] = [];
    
    for (const wishlistItem of userWishlistItems) {
      const product = await this.getProduct(wishlistItem.productId);
      if (product) {
        result.push({ wishlistItem, product });
      }
    }
    
    return result;
  }
  
  async getWishlistItem(userId: number, productId: number): Promise<WishlistItem | undefined> {
    const [wishlistItem] = await db.select().from(wishlistItems).where(
      and(
        eq(wishlistItems.userId, userId),
        eq(wishlistItems.productId, productId)
      )
    );
    
    return wishlistItem;
  }
  
  async createWishlistItem(wishlistItem: InsertWishlistItem): Promise<WishlistItem> {
    const [newWishlistItem] = await db.insert(wishlistItems).values(wishlistItem).returning();
    return newWishlistItem;
  }
  
  async deleteWishlistItem(id: number): Promise<boolean> {
    await db.delete(wishlistItems).where(eq(wishlistItems.id, id));
    return true;
  }
  
  // Admin user and sample data initialization
  async initializeAdminUser(): Promise<User> {
    // Check if admin already exists
    const existingAdmin = await this.getUserByUsername("admin");
    if (existingAdmin) {
      return existingAdmin;
    }
    
    // Create admin user with specified credentials
    const hashedPassword = await bcrypt.hash("Br<<$1994pro", 10);
    
    // Create admin user without isAdmin first, then update it
    const adminUser: InsertUser = {
      username: "admin",
      password: hashedPassword,
      email: "admin@example.com",
      name: "Admin User"
    };
    
    // Create the user
    const user = await this.createUser(adminUser);
    
    // Then update directly in the database to set isAdmin flag
    if (user) {
      await db.update(users)
        .set({ isAdmin: true })
        .where(eq(users.id, user.id));
      
      // Return updated user with admin privileges
      return { ...user, isAdmin: true };
    }
    
    return user;
  }
  
  async initializeSampleData(): Promise<void> {
    // Initialize categories
    const categories = await this.getAllCategories();
    
    if (categories.length === 0) {
      await this.createCategory({
        name: "Smartphones",
        slug: "smartphones",
        description: "Smartphones e celulares de última geração",
        image: "/images/categories/smartphones.jpg"
      });
      
      await this.createCategory({
        name: "Laptops",
        slug: "laptops",
        description: "Notebooks e laptops para todas as necessidades",
        image: "/images/categories/laptops.jpg"
      });
      
      await this.createCategory({
        name: "Tablets",
        slug: "tablets",
        description: "Tablets e dispositivos portáteis",
        image: "/images/categories/tablets.jpg"
      });
      
      await this.createCategory({
        name: "Áudio",
        slug: "audio",
        description: "Fones de ouvido, caixas de som e equipamentos de áudio",
        image: "/images/categories/audio.jpg"
      });
      
      await this.createCategory({
        name: "Acessórios",
        slug: "accessories",
        description: "Acessórios para seus dispositivos",
        image: "/images/categories/accessories.jpg"
      });
    }
    
    // Initialize products
    const products = await this.getAllProducts();
    
    if (products.length === 0) {
      // Smartphones
      await this.createProduct({
        name: "Smartphone 128GB Ultra",
        slug: "smartphone-128gb-ultra",
        description: "O mais avançado smartphone com 128GB de armazenamento, câmera de 108MP e tela AMOLED de 6.7 polegadas.",
        price: 4999.99,
        compareAtPrice: 5499.99,
        image: "/images/products/smartphone-1.jpg",
        images: ["/images/products/smartphone-1-1.jpg", "/images/products/smartphone-1-2.jpg", "/images/products/smartphone-1-3.jpg"],
        categoryId: 1,
        inStock: true,
        isFeatured: true,
        isNew: true,
        specs: {
          processor: "Octa-core 2.8GHz",
          ram: "12GB",
          storage: "128GB",
          screen: "6.7\" AMOLED",
          camera: "108MP + 12MP + 10MP",
          battery: "5000mAh"
        }
      });
      
      await this.createProduct({
        name: "Smartphone Básico 64GB",
        slug: "smartphone-basic-64gb",
        description: "Smartphone de entrada com excelente custo-benefício, 64GB de armazenamento e câmera dupla.",
        price: 1599.99,
        compareAtPrice: 1899.99,
        image: "/images/products/smartphone-2.jpg",
        images: ["/images/products/smartphone-2-1.jpg", "/images/products/smartphone-2-2.jpg"],
        categoryId: 1,
        inStock: true,
        isFeatured: false,
        isNew: false,
        specs: {
          processor: "Octa-core 2.0GHz",
          ram: "4GB",
          storage: "64GB",
          screen: "6.5\" LCD",
          camera: "48MP + 5MP",
          battery: "4500mAh"
        }
      });
      
      // Laptops
      await this.createProduct({
        name: "Notebook Ultra Fino i7 16GB",
        slug: "notebook-ultra-thin-i7-16gb",
        description: "Notebook ultrafino com processador i7 de 11ª geração, 16GB de RAM e SSD de 512GB.",
        price: 7999.99,
        compareAtPrice: 8499.99,
        image: "/images/products/laptop-1.jpg",
        images: ["/images/products/laptop-1-1.jpg", "/images/products/laptop-1-2.jpg"],
        categoryId: 2,
        inStock: true,
        isFeatured: true,
        isNew: true,
        specs: {
          processor: "Intel Core i7 11ª Geração",
          ram: "16GB",
          storage: "512GB SSD",
          screen: "15.6\" Full HD IPS",
          graphics: "NVIDIA GeForce RTX 3050 4GB",
          battery: "8 horas"
        }
      });
      
      // Audio
      await this.createProduct({
        name: "Fones de Ouvido Bluetooth sem Fio",
        slug: "wireless-bluetooth-headphones",
        description: "Fones de ouvido bluetooth com cancelamento de ruído, bateria de longa duração e qualidade de áudio premium.",
        price: 899.99,
        compareAtPrice: 999.99,
        image: "/images/products/headphones-1.jpg",
        images: ["/images/products/headphones-1-1.jpg", "/images/products/headphones-1-2.jpg"],
        categoryId: 4,
        inStock: true,
        isFeatured: true,
        isNew: false,
        specs: {
          type: "Over-ear",
          connectivity: "Bluetooth 5.0",
          batteryLife: "30 horas",
          noiseCancel: "Ativo",
          microphone: "Integrado",
          weight: "250g"
        }
      });
      
      await this.createProduct({
        name: "Caixa de Som Bluetooth à Prova D'água",
        slug: "waterproof-bluetooth-speaker",
        description: "Caixa de som bluetooth à prova d'água, perfeita para festas na piscina ou praia, com até 12 horas de reprodução.",
        price: 399.99,
        compareAtPrice: 499.99,
        image: "/images/products/speaker-1.jpg",
        images: ["/images/products/speaker-1-1.jpg", "/images/products/speaker-1-2.jpg"],
        categoryId: 4,
        inStock: true,
        isFeatured: false,
        isNew: true,
        specs: {
          power: "30W",
          connectivity: "Bluetooth 5.0",
          batteryLife: "12 horas",
          waterproof: "IPX7",
          dimensions: "220 x 95 x 93 mm",
          weight: "960g"
        }
      });
      
      // Accessories
      await this.createProduct({
        name: "Carregador Rápido USB-C 45W",
        slug: "fast-charger-usb-c-45w",
        description: "Carregador rápido com porta USB-C, potência de 45W, compatível com smartphones, tablets e laptops.",
        price: 199.99,
        compareAtPrice: 249.99,
        image: "/images/products/charger-1.jpg",
        images: ["/images/products/charger-1-1.jpg"],
        categoryId: 5,
        inStock: true,
        isFeatured: false,
        isNew: false,
        specs: {
          power: "45W",
          ports: "1x USB-C",
          inputVoltage: "100-240V",
          technologies: "Power Delivery 3.0, Quick Charge 4.0",
          dimensions: "75 x 35 x 35 mm",
          weight: "120g"
        }
      });
    }
  }
}

export const storage = new DatabaseStorage();