import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcryptjs";
import MemoryStore from "memorystore";
import Stripe from "stripe";
import { 
  insertUserSchema, 
  loginSchema, 
  insertProductSchema, 
  insertCartItemSchema,
  insertWishlistItemSchema
} from "@shared/schema";
import { ZodError } from "zod";

// Configure session store
const MemoryStoreSession = MemoryStore(session);
const sessionStore = new MemoryStoreSession({
  checkPeriod: 86400000, // Prune expired entries every 24h
});

// Configure Stripe
if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('Warning: Missing Stripe secret key. Payment processing will not work.');
}

const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" })
  : undefined;

// Verificar se o stripe está configurado
if (!stripe) {
  console.error('Stripe is not configured properly. Payment processing will not work.');
}

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: any) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Not authenticated" });
};

// Middleware to check if user is admin
const isAdmin = (req: Request, res: Response, next: any) => {
  if (req.isAuthenticated() && req.user.isAdmin) {
    return next();
  }
  res.status(403).json({ message: "Not authorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session
  app.use(session({
    secret: process.env.SESSION_SECRET || "tech-drop-secret",
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24, // 1 day
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    }
  }));

  // Configure passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure local strategy
  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return done(null, false, { message: "Incorrect username" });
      }
      
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return done(null, false, { message: "Incorrect password" });
      }
      
      return done(null, user);
    } catch (err) {
      return done(err);
    }
  }));

  // Serialize and deserialize user
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Auth Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Create user
      const user = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/auth/login", (req, res, next) => {
    try {
      loginSchema.parse(req.body);
      passport.authenticate("local", (err: any, user: any, info: any) => {
        if (err) {
          return next(err);
        }
        if (!user) {
          return res.status(401).json({ message: info.message });
        }
        req.logIn(user, (err) => {
          if (err) {
            return next(err);
          }
          
          // Remove password from response
          const { password, ...userWithoutPassword } = user;
          
          return res.json({ user: userWithoutPassword });
        });
      })(req, res, next);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Server error" });
      }
      res.json({ message: "Logged out" });
    });
  });

  app.get("/api/auth/me", isAuthenticated, (req, res) => {
    // Remove password from response
    const { password, ...userWithoutPassword } = req.user as any;
    
    res.json(userWithoutPassword);
  });

  // Categories Routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/categories/:slug", async (req, res) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Products Routes
  app.get("/api/products", async (req, res) => {
    try {
      let products;
      
      if (req.query.featured) {
        const limit = req.query.limit ? Number(req.query.limit) : undefined;
        products = await storage.getFeaturedProducts(limit);
      } else if (req.query.new) {
        const limit = req.query.limit ? Number(req.query.limit) : undefined;
        products = await storage.getNewProducts(limit);
      } else if (req.query.category) {
        const category = await storage.getCategoryBySlug(req.query.category as string);
        if (!category) {
          return res.status(404).json({ message: "Category not found" });
        }
        products = await storage.getProductsByCategory(category.id);
      } else if (req.query.search) {
        products = await storage.searchProducts(req.query.search as string);
      } else {
        products = await storage.getAllProducts();
      }
      
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/products/:slug", async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Admin Product Management
  app.post("/api/products", isAdmin, async (req, res) => {
    try {
      const productData = insertProductSchema.parse(req.body);
      
      // Check if slug already exists
      const existingProduct = await storage.getProductBySlug(productData.slug);
      if (existingProduct) {
        return res.status(400).json({ message: "Product with this slug already exists" });
      }
      
      const product = await storage.createProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/products/:id", isAdmin, async (req, res) => {
    try {
      const productId = Number(req.params.id);
      
      // Check if product exists
      const existingProduct = await storage.getProduct(productId);
      if (!existingProduct) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // If slug is being updated, check if it's unique
      if (req.body.slug && req.body.slug !== existingProduct.slug) {
        const productWithSlug = await storage.getProductBySlug(req.body.slug);
        if (productWithSlug) {
          return res.status(400).json({ message: "Product with this slug already exists" });
        }
      }
      
      const product = await storage.updateProduct(productId, req.body);
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/products/:id", isAdmin, async (req, res) => {
    try {
      const productId = Number(req.params.id);
      
      // Check if product exists
      const existingProduct = await storage.getProduct(productId);
      if (!existingProduct) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      await storage.deleteProduct(productId);
      res.json({ message: "Product deleted" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Cart Routes
  app.get("/api/cart", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const cartItems = await storage.getCartItemWithProduct(user.id);
      
      // Calculate total
      const total = cartItems.reduce((acc, { cartItem, product }) => {
        return acc + (product.price * cartItem.quantity);
      }, 0);
      
      res.json({
        items: cartItems,
        total: total
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/cart", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const cartItemData = insertCartItemSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      // Check if product exists
      const product = await storage.getProduct(cartItemData.productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Check if product is in stock
      if (!product.inStock) {
        return res.status(400).json({ message: "Product is out of stock" });
      }
      
      // Check if item already exists in cart
      const existingCartItem = await storage.getCartItem(user.id, cartItemData.productId);
      if (existingCartItem) {
        // Update quantity
        const updatedCartItem = await storage.updateCartItemQuantity(
          existingCartItem.id, 
          existingCartItem.quantity + (cartItemData.quantity || 1)
        );
        
        return res.json(updatedCartItem);
      }
      
      // Create new cart item
      const cartItem = await storage.createCartItem(cartItemData);
      res.status(201).json(cartItem);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/cart/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const cartItemId = Number(req.params.id);
      const quantity = Number(req.body.quantity);
      
      // Check if cart item exists and belongs to user
      const cartItems = await storage.getUserCartItems(user.id);
      const cartItem = cartItems.find(item => item.id === cartItemId);
      
      if (!cartItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      // Update quantity
      const updatedCartItem = await storage.updateCartItemQuantity(cartItemId, quantity);
      res.json(updatedCartItem);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/cart/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const cartItemId = Number(req.params.id);
      
      // Check if cart item exists and belongs to user
      const cartItems = await storage.getUserCartItems(user.id);
      const cartItem = cartItems.find(item => item.id === cartItemId);
      
      if (!cartItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      await storage.deleteCartItem(cartItemId);
      res.json({ message: "Cart item deleted" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/cart", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      await storage.clearCart(user.id);
      res.json({ message: "Cart cleared" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Wishlist Routes
  app.get("/api/wishlist", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const wishlistItems = await storage.getWishlistItemWithProduct(user.id);
      res.json(wishlistItems);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/wishlist", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const wishlistItemData = insertWishlistItemSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      // Check if product exists
      const product = await storage.getProduct(wishlistItemData.productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Check if item already exists in wishlist
      const existingWishlistItem = await storage.getWishlistItem(user.id, wishlistItemData.productId);
      if (existingWishlistItem) {
        return res.status(400).json({ message: "Product already in wishlist" });
      }
      
      // Create new wishlist item
      const wishlistItem = await storage.createWishlistItem(wishlistItemData);
      res.status(201).json(wishlistItem);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/wishlist/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const wishlistItemId = Number(req.params.id);
      
      // Check if wishlist item exists and belongs to user
      const wishlistItems = await storage.getUserWishlistItems(user.id);
      const wishlistItem = wishlistItems.find(item => item.id === wishlistItemId);
      
      if (!wishlistItem) {
        return res.status(404).json({ message: "Wishlist item not found" });
      }
      
      await storage.deleteWishlistItem(wishlistItemId);
      res.json({ message: "Wishlist item deleted" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Order Routes
  app.get("/api/orders", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const orders = await storage.getUserOrders(user.id);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/orders/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const orderId = Number(req.params.id);
      
      const orderWithItems = await storage.getOrderWithItems(orderId);
      if (!orderWithItems) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if order belongs to user or user is admin
      if (orderWithItems.order.userId !== user.id && !user.isAdmin) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      res.json(orderWithItems);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Stripe payment
  app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Stripe is not configured" });
      }
      
      const user = req.user as any;
      const { amount } = req.body;
      
      // Create payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId: user.id
        }
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error("Stripe error:", error);
      res.status(500).json({ message: "Error creating payment intent" });
    }
  });

  // Checkout
  app.post("/api/checkout", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { shippingAddress, paymentMethod, paymentId } = req.body;
      
      // Get cart items
      const cartItems = await storage.getCartItemWithProduct(user.id);
      if (cartItems.length === 0) {
        return res.status(400).json({ message: "Cart is empty" });
      }
      
      // Calculate total
      const total = cartItems.reduce((acc, { cartItem, product }) => {
        return acc + (product.price * cartItem.quantity);
      }, 0);
      
      // Create order
      const order = await storage.createOrder({
        userId: user.id,
        total,
        status: "pending",
        shippingAddress,
        paymentMethod,
        paymentId
      });
      
      // Create order items
      for (const { cartItem, product } of cartItems) {
        await storage.createOrderItem({
          orderId: order.id,
          productId: product.id,
          quantity: cartItem.quantity,
          price: product.price,
          name: product.name,
          image: product.image
        });
      }
      
      // Clear cart
      await storage.clearCart(user.id);
      
      res.status(201).json({ orderId: order.id });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Admin Routes
  app.get("/api/admin/orders", isAdmin, async (req, res) => {
    try {
      // Get all orders from all users
      const orders = Array.from((await storage).orders.values())
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/admin/orders/:id", isAdmin, async (req, res) => {
    try {
      const orderId = Number(req.params.id);
      const { status } = req.body;
      
      const updatedOrder = await storage.updateOrderStatus(orderId, status);
      if (!updatedOrder) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Stripe Payment Routes
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Stripe is not configured" });
      }

      const { cartItems, total } = req.body;
      
      if (!cartItems || !cartItems.length || !total) {
        return res.status(400).json({ message: "Invalid request data" });
      }

      // Criando PaymentIntent com o valor do carrinho
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(total * 100), // Convertendo para centavos
        currency: "brl",
        automatic_payment_methods: {
          enabled: true,
        },
        metadata: {
          cart_items: JSON.stringify(cartItems.map((item: any) => ({
            product_id: item.product.id,
            name: item.product.name,
            price: item.product.price,
            quantity: item.cartItem.quantity
          })))
        }
      });

      res.json({
        clientSecret: paymentIntent.client_secret
      });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment: " + error.message });
    }
  });

  // Webhooks para confirmar pagamentos (você precisará configurar isto no Stripe Dashboard)
  app.post("/api/webhook", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Stripe is not configured" });
      }

      const sig = req.headers['stripe-signature'] as string;
      const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

      if (!endpointSecret) {
        console.warn("Webhook secret is not configured, skipping verification");
        // Processar o evento sem verificação de assinatura
      } else {
        let event;
        try {
          event = stripe.webhooks.constructEvent(
            req.body,
            sig,
            endpointSecret
          );
        } catch (err: any) {
          console.log(`⚠️ Webhook signature verification failed. ${err.message}`);
          return res.status(400).send(`Webhook Error: ${err.message}`);
        }

        // Manipular o evento
        switch (event.type) {
          case 'payment_intent.succeeded':
            const paymentIntent = event.data.object;
            console.log(`PaymentIntent for ${paymentIntent.amount} was successful!`);
            // Aqui você processaria o pedido no seu sistema
            break;
          case 'payment_intent.payment_failed':
            const failedPaymentIntent = event.data.object;
            console.log(`PaymentIntent for ${failedPaymentIntent.amount} failed.`);
            break;
          default:
            console.log(`Unhandled event type ${event.type}`);
        }
      }

      res.json({ received: true });
    } catch (error: any) {
      console.error("Error processing webhook:", error);
      res.status(500).json({ message: "Error processing webhook: " + error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
