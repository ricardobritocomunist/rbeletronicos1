import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import ProductList from "@/pages/ProductList";
import ProductDetail from "@/pages/ProductDetail";
import Cart from "@/pages/Cart";
import Checkout from "@/pages/Checkout";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import UserProfile from "@/pages/UserProfile";
import OrderHistory from "@/pages/OrderHistory";
import AdminDashboard from "@/pages/Admin/Dashboard";
import ProductManagement from "@/pages/Admin/ProductManagement";
import OrderManagement from "@/pages/Admin/OrderManagement";
import NotFound from "@/pages/not-found";

function App() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/products" component={ProductList} />
        <Route path="/products/category/:slug" component={ProductList} />
        <Route path="/products/:slug" component={ProductDetail} />
        <Route path="/cart" component={Cart} />
        <Route path="/checkout" component={Checkout} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/profile" component={UserProfile} />
        <Route path="/orders" component={OrderHistory} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/admin/products" component={ProductManagement} />
        <Route path="/admin/orders" component={OrderManagement} />
        <Route component={NotFound} />
      </Switch>
      <Toaster />
    </Layout>
  );
}

export default App;
