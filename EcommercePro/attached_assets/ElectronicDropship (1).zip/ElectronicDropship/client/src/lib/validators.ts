import { z } from "zod";

/**
 * Login form validator
 */
export const loginSchema = z.object({
  username: z.string().min(1, "Nome de usuário é obrigatório"),
  password: z.string().min(1, "Senha é obrigatória"),
});

/**
 * Registration form validator
 */
export const registerSchema = z.object({
  username: z.string()
    .min(3, "Nome de usuário deve ter pelo menos 3 caracteres")
    .max(30, "Nome de usuário deve ter no máximo 30 caracteres")
    .regex(/^[a-zA-Z0-9._-]+$/, "Nome de usuário deve conter apenas letras, números e símbolos como . _ -"),
  password: z.string()
    .min(6, "Senha deve ter pelo menos 6 caracteres")
    .max(100, "Senha muito longa"),
  email: z.string()
    .email("Email inválido"),
  name: z.string()
    .min(2, "Nome deve ter pelo menos 2 caracteres")
    .max(100, "Nome muito longo"),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  postalCode: z.string().optional(),
  country: z.string().optional(),
  phone: z.string().optional(),
});

/**
 * Profile update form validator
 */
export const updateProfileSchema = registerSchema.omit({ 
  username: true, 
  password: true 
}).extend({
  password: z.string().optional(),
});

/**
 * Product form validator
 */
export const productSchema = z.object({
  name: z.string().min(3, "Nome do produto deve ter pelo menos 3 caracteres"),
  slug: z.string().min(3, "Slug deve ter pelo menos 3 caracteres"),
  description: z.string().min(10, "Descrição deve ter pelo menos 10 caracteres"),
  price: z.coerce.number().positive("Preço deve ser positivo"),
  compareAtPrice: z.coerce.number().positive("Preço comparativo deve ser positivo").optional(),
  image: z.string().url("URL da imagem inválida"),
  images: z.array(z.string().url("URL da imagem inválida")).optional(),
  categoryId: z.coerce.number().positive("Categoria é obrigatória"),
  inStock: z.boolean().default(true),
  isFeatured: z.boolean().default(false),
  isNew: z.boolean().default(false),
  specs: z.record(z.string()).optional(),
});

/**
 * Shipping address validator
 */
export const shippingAddressSchema = z.object({
  name: z.string().min(2, "Nome é obrigatório"),
  address: z.string().min(5, "Endereço é obrigatório"),
  city: z.string().min(2, "Cidade é obrigatória"),
  state: z.string().min(2, "Estado é obrigatório"),
  postalCode: z.string().min(5, "CEP é obrigatório"),
  country: z.string().min(2, "País é obrigatório"),
  phone: z.string().min(8, "Telefone é obrigatório"),
});

/**
 * Payment method validator
 */
export const paymentMethodSchema = z.object({
  method: z.enum(["credit_card", "pix", "bank_slip"]),
});

/**
 * Order status validator
 */
export const orderStatusSchema = z.object({
  status: z.enum(["pending", "processing", "shipped", "delivered", "cancelled"]),
});

/**
 * Search query validator
 */
export const searchQuerySchema = z.object({
  query: z.string().min(1, "Termo de busca é obrigatório"),
});

/**
 * Newsletter subscription validator
 */
export const newsletterSchema = z.object({
  email: z.string().email("Email inválido"),
});
