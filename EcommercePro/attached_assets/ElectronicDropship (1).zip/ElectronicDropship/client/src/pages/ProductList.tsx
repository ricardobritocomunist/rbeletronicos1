import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { Helmet } from "react-helmet";
import { 
  Filter, 
  Search, 
  ChevronDown, 
  ArrowUpDown,
  SlidersHorizontal 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
  SheetClose
} from "@/components/ui/sheet";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import ProductCard from "@/components/ui/product-card";
import { Skeleton } from "@/components/ui/skeleton";

const sortOptions = [
  { value: "relevance", label: "Relevância" },
  { value: "price-asc", label: "Preço: Menor para Maior" },
  { value: "price-desc", label: "Preço: Maior para Menor" },
  { value: "rating-desc", label: "Avaliações: Melhores primeiro" },
  { value: "newest", label: "Lançamentos" }
];

const ProductList = () => {
  const [searchParams] = useLocation();
  const params = useParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("relevance");
  const [categoryFilters, setCategoryFilters] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState({ min: "", max: "" });
  const [inStockOnly, setInStockOnly] = useState(false);
  
  // Parse query parameters
  const queryParams = new URLSearchParams(searchParams);
  const search = queryParams.get("search") || "";
  const featured = queryParams.get("featured") === "true";
  const newProducts = queryParams.get("new") === "true";
  
  // Build API endpoint based on filters and params
  const getEndpoint = () => {
    let endpoint = "/api/products";
    const filters = [];
    
    if (params.slug) {
      endpoint = `/api/products?category=${params.slug}`;
    } else if (featured) {
      filters.push("featured=true");
    } else if (newProducts) {
      filters.push("new=true");
    } else if (search) {
      filters.push(`search=${search}`);
    }
    
    if (filters.length > 0) {
      endpoint = `${endpoint}?${filters.join("&")}`;
    }
    
    return endpoint;
  };
  
  // Get category data if we're filtering by category
  const { data: category } = useQuery({
    queryKey: [params.slug ? `/api/categories/${params.slug}` : null],
    enabled: !!params.slug,
  });
  
  // Get all categories for filters
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Get products with filters
  const { data: products, isLoading } = useQuery({
    queryKey: [getEndpoint()],
  });
  
  // Update search query from URL on initial load
  useEffect(() => {
    if (search) {
      setSearchQuery(search);
    }
  }, [search]);
  
  // Local sort function
  const sortProducts = (products) => {
    if (!products) return [];
    
    const productsCopy = [...products];
    
    switch (sortBy) {
      case "price-asc":
        return productsCopy.sort((a, b) => a.price - b.price);
      case "price-desc":
        return productsCopy.sort((a, b) => b.price - a.price);
      case "rating-desc":
        return productsCopy.sort((a, b) => b.rating - a.rating);
      case "newest":
        return productsCopy.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      default:
        return productsCopy;
    }
  };
  
  const sortedProducts = sortProducts(products);
  
  // Get page title
  const getPageTitle = () => {
    if (params.slug && category) {
      return `${category.name} | TechDrop`;
    } else if (featured) {
      return "Produtos em Destaque | TechDrop";
    } else if (newProducts) {
      return "Novidades | TechDrop";
    } else if (search) {
      return `Busca: ${search} | TechDrop`;
    } else {
      return "Todos os Produtos | TechDrop";
    }
  };
  
  return (
    <>
      <Helmet>
        <title>{getPageTitle()}</title>
        <meta 
          name="description" 
          content={`Explore nossa seleção de ${params.slug ? category?.name : "produtos eletrônicos"}. Encontre os melhores preços em smartphones, fones de ouvido, smartwatches e mais.`} 
        />
      </Helmet>
      
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">
          {params.slug && category ? category.name : 
           featured ? "Produtos em Destaque" :
           newProducts ? "Novidades" :
           search ? `Resultados para "${search}"` : "Todos os Produtos"}
        </h1>
        
        {params.slug && category && (
          <p className="text-gray-600 mb-4">{category.description}</p>
        )}
        
        {/* Search and Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between mt-6 mb-8">
          <div className="w-full md:w-auto flex-1 max-w-md">
            <div className="relative">
              <Input
                type="text"
                placeholder="Buscar produtos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute right-0 top-0 h-full"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex items-center gap-2 w-full md:w-auto">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="flex items-center gap-2">
                  <SlidersHorizontal className="h-4 w-4" />
                  <span className="hidden md:inline">Filtros</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <SheetHeader>
                  <SheetTitle>Filtros</SheetTitle>
                  <SheetDescription>
                    Refine sua busca com os filtros abaixo
                  </SheetDescription>
                </SheetHeader>
                
                <div className="py-4">
                  <h3 className="font-medium mb-2">Categorias</h3>
                  <div className="space-y-2">
                    {categories?.map((cat) => (
                      <div key={cat.id} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`category-${cat.id}`} 
                          checked={categoryFilters.includes(cat.slug)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setCategoryFilters([...categoryFilters, cat.slug]);
                            } else {
                              setCategoryFilters(categoryFilters.filter(c => c !== cat.slug));
                            }
                          }}
                        />
                        <Label htmlFor={`category-${cat.id}`}>{cat.name}</Label>
                      </div>
                    ))}
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <h3 className="font-medium mb-2">Preço</h3>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      placeholder="Mín"
                      value={priceRange.min}
                      onChange={(e) => setPriceRange({ ...priceRange, min: e.target.value })}
                      className="w-24"
                    />
                    <span>-</span>
                    <Input
                      type="number"
                      placeholder="Máx"
                      value={priceRange.max}
                      onChange={(e) => setPriceRange({ ...priceRange, max: e.target.value })}
                      className="w-24"
                    />
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="in-stock" 
                      checked={inStockOnly}
                      onCheckedChange={(checked) => setInStockOnly(!!checked)}
                    />
                    <Label htmlFor="in-stock">Apenas produtos em estoque</Label>
                  </div>
                </div>
                
                <SheetFooter>
                  <SheetClose asChild>
                    <Button>Aplicar Filtros</Button>
                  </SheetClose>
                </SheetFooter>
              </SheetContent>
            </Sheet>
            
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Product Grid */}
        {isLoading ? (
          <div className="product-grid">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl overflow-hidden shadow-md">
                <Skeleton className="w-full h-48" />
                <div className="p-4">
                  <Skeleton className="h-4 w-24 mb-1" />
                  <Skeleton className="h-5 w-40 mb-1" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-10 w-10 rounded-lg" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : sortedProducts?.length > 0 ? (
          <div className="product-grid">
            {sortedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="bg-gray-100 p-8 rounded-lg text-center">
            <h3 className="text-lg font-medium mb-2">Nenhum produto encontrado</h3>
            <p className="text-gray-600">
              Tente alterar seus filtros ou busque por outro termo.
            </p>
          </div>
        )}
      </div>
    </>
  );
};

export default ProductList;
