import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNavbar from "@/components/layout/MobileNavbar";
import ProductCard from "@/components/product/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronDown, SlidersHorizontal } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Category() {
  const [, params] = useRoute("/category/:slug");
  const slug = params?.slug;
  const [priceRange, setPriceRange] = useState({ min: "", max: "" });
  const [sortBy, setSortBy] = useState("newest");
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Fetch category data
  const { 
    data: category,
    isLoading: isLoadingCategory,
    error: categoryError 
  } = useQuery({
    queryKey: [`/api/categories/${slug}`],
    enabled: !!slug && slug !== "all",
  });

  // Fetch products for the category
  const { 
    data: products,
    isLoading: isLoadingProducts,
    error: productsError 
  } = useQuery({
    queryKey: [slug === "all" ? "/api/products" : `/api/products/category/${slug}`],
    enabled: !!slug,
  });

  // Filtered and sorted products
  const filteredProducts = products
    ? products.filter((product: any) => {
        if (priceRange.min && Number(product.price) < Number(priceRange.min)) {
          return false;
        }
        if (priceRange.max && Number(product.price) > Number(priceRange.max)) {
          return false;
        }
        return true;
      })
    : [];

  const sortedProducts = [...filteredProducts].sort((a: any, b: any) => {
    switch (sortBy) {
      case "price-low":
        return Number(a.price) - Number(b.price);
      case "price-high":
        return Number(b.price) - Number(a.price);
      case "name":
        return a.name.localeCompare(b.name);
      case "newest":
      default:
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  useEffect(() => {
    if (category) {
      document.title = `${category.name} | TechDrop`;
      
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute("content", category.description || `Explore nossa coleção de ${category.name} com os melhores preços e ofertas exclusivas.`);
      }
    } else if (slug === "all") {
      document.title = "Todos os Produtos | TechDrop";
      
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute("content", "Explore nossa coleção completa de produtos eletrônicos com os melhores preços e qualidade garantida.");
      }
    }
  }, [category, slug]);

  // Filter functions
  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>, type: "min" | "max") => {
    setPriceRange({ ...priceRange, [type]: e.target.value });
  };

  const handleSortChange = (value: string) => {
    setSortBy(value);
  };

  const clearFilters = () => {
    setPriceRange({ min: "", max: "" });
    setSortBy("newest");
  };

  // Render filter sidebar/sheet
  const FilterContent = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-3">Filtros</h3>
        <Button 
          variant="ghost" 
          className="text-gray-500 text-sm"
          onClick={clearFilters}
        >
          Limpar Filtros
        </Button>
      </div>
      
      <div>
        <h4 className="font-medium mb-3">Faixa de Preço</h4>
        <div className="flex items-center space-x-3">
          <Input
            type="number"
            placeholder="Mín"
            value={priceRange.min}
            onChange={(e) => handlePriceChange(e, "min")}
            className="w-24"
          />
          <span>-</span>
          <Input
            type="number"
            placeholder="Máx"
            value={priceRange.max}
            onChange={(e) => handlePriceChange(e, "max")}
            className="w-24"
          />
        </div>
      </div>
      
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="availability">
          <AccordionTrigger>Disponibilidade</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="in-stock" className="mr-2" />
                <label htmlFor="in-stock">Em estoque</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="out-of-stock" className="mr-2" />
                <label htmlFor="out-of-stock">Fora de estoque</label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="ratings">
          <AccordionTrigger>Avaliações</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {[5, 4, 3, 2, 1].map((rating) => (
                <div key={rating} className="flex items-center">
                  <input type="checkbox" id={`rating-${rating}`} className="mr-2" />
                  <label htmlFor={`rating-${rating}`}>
                    {rating} {rating === 1 ? "estrela" : "estrelas"} ou mais
                  </label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );

  if (categoryError || productsError) {
    return (
      <>
        <Header />
        <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
          <div className="bg-red-50 p-6 rounded-lg text-red-500">
            <h2 className="text-lg font-bold mb-2">Erro ao carregar produtos</h2>
            <p>Não foi possível carregar os produtos. Por favor, tente novamente mais tarde.</p>
          </div>
        </main>
        <Footer />
        <MobileNavbar />
      </>
    );
  }

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
        {/* Category Header */}
        <div className="mb-8">
          {isLoadingCategory && slug !== "all" ? (
            <Skeleton className="h-10 w-1/3 mb-2" />
          ) : (
            <h1 className="text-3xl font-bold">
              {slug === "all" ? "Todos os Produtos" : category?.name}
            </h1>
          )}
          
          {isLoadingCategory && slug !== "all" ? (
            <Skeleton className="h-5 w-full max-w-2xl" />
          ) : (
            <p className="text-gray-600">
              {slug === "all" 
                ? "Explore nossa coleção completa de produtos eletrônicos." 
                : category?.description}
            </p>
          )}
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="hidden md:block w-64 flex-shrink-0">
            <Card>
              <CardHeader>
                <CardTitle>Filtros</CardTitle>
              </CardHeader>
              <CardContent>
                <FilterContent />
              </CardContent>
            </Card>
          </div>

          {/* Products Grid */}
          <div className="flex-1">
            {/* Sort and Filter Controls */}
            <div className="flex flex-wrap justify-between items-center mb-6 gap-3">
              <div className="flex items-center space-x-2 md:space-x-4">
                {/* Mobile Filter Button */}
                <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="md:hidden">
                      <SlidersHorizontal className="h-4 w-4 mr-2" />
                      Filtros
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left">
                    <div className="py-6">
                      <FilterContent />
                    </div>
                  </SheetContent>
                </Sheet>
                
                {/* Results Count */}
                <p className="text-gray-500">
                  {isLoadingProducts 
                    ? "Carregando produtos..." 
                    : `${sortedProducts.length} produtos encontrados`}
                </p>
              </div>
              
              {/* Sorting */}
              <div className="flex items-center space-x-2">
                <span className="text-gray-700">Ordenar por:</span>
                <Select value={sortBy} onValueChange={handleSortChange}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Mais Recentes</SelectItem>
                    <SelectItem value="price-low">Menor Preço</SelectItem>
                    <SelectItem value="price-high">Maior Preço</SelectItem>
                    <SelectItem value="name">Nome</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Products */}
            {isLoadingProducts ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, index) => (
                  <Skeleton key={index} className="aspect-[3/4] rounded-xl" />
                ))}
              </div>
            ) : sortedProducts.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
                {sortedProducts.map((product: any) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 p-8 rounded-xl text-center">
                <h2 className="text-xl font-semibold mb-2">Nenhum produto encontrado</h2>
                <p className="text-gray-600 mb-4">
                  Não encontramos produtos que correspondam aos filtros selecionados.
                </p>
                <Button 
                  variant="outline" 
                  onClick={clearFilters}
                >
                  Limpar Filtros
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
      <MobileNavbar />
    </>
  );
}
