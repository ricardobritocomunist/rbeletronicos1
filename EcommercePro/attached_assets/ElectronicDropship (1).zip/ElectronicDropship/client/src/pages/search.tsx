import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNavbar from "@/components/layout/MobileNavbar";
import ProductCard from "@/components/product/ProductCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Search as SearchIcon } from "lucide-react";

export default function Search() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1]);
  const initialQuery = searchParams.get("q") || "";
  
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [sortBy, setSortBy] = useState("relevance");
  
  // Fetch search results
  const { 
    data: products,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ["/api/products", { search: initialQuery }],
    enabled: initialQuery.length > 0,
  });

  // Sort products
  const sortedProducts = products 
    ? [...products].sort((a: any, b: any) => {
        switch (sortBy) {
          case "price-low":
            return Number(a.price) - Number(b.price);
          case "price-high":
            return Number(b.price) - Number(a.price);
          case "name":
            return a.name.localeCompare(b.name);
          case "newest":
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
          case "relevance":
          default:
            // For relevance, we could implement more complex logic
            // For now, just show in original order
            return 0;
        }
      })
    : [];

  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      window.history.pushState(
        null, 
        "", 
        `/search?q=${encodeURIComponent(searchTerm.trim())}`
      );
      refetch();
    }
  };

  // Handle sort change
  const handleSortChange = (value: string) => {
    setSortBy(value);
  };

  useEffect(() => {
    document.title = `Busca: ${initialQuery} | TechDrop`;
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", `Resultados de busca para "${initialQuery}" - Encontre produtos eletrônicos de qualidade com os melhores preços na TechDrop.`);
    }
  }, [initialQuery]);

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
        {/* Search Header */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-4">
            {initialQuery 
              ? `Resultados para "${initialQuery}"` 
              : "Buscar Produtos"}
          </h1>
          
          <form onSubmit={handleSearch} className="flex w-full max-w-lg gap-2">
            <Input
              type="text"
              placeholder="O que você está procurando?"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" className="bg-primary hover:bg-primary/90">
              <SearchIcon className="h-4 w-4 mr-2" />
              Buscar
            </Button>
          </form>
        </div>

        {/* Search Results */}
        {initialQuery && (
          <>
            {/* Sort Controls */}
            <div className="flex justify-between items-center mb-6">
              <p className="text-gray-500">
                {isLoading 
                  ? "Procurando produtos..." 
                  : `${sortedProducts.length} produto(s) encontrado(s)`}
              </p>
              
              <div className="flex items-center space-x-2">
                <span className="text-gray-700">Ordenar por:</span>
                <Select value={sortBy} onValueChange={handleSortChange}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relevance">Relevância</SelectItem>
                    <SelectItem value="price-low">Menor Preço</SelectItem>
                    <SelectItem value="price-high">Maior Preço</SelectItem>
                    <SelectItem value="newest">Mais Recentes</SelectItem>
                    <SelectItem value="name">Nome</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Products */}
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {Array.from({ length: 8 }).map((_, index) => (
                  <Skeleton key={index} className="aspect-[3/4] rounded-xl" />
                ))}
              </div>
            ) : error ? (
              <div className="bg-red-50 p-6 rounded-lg text-red-500">
                <h2 className="text-lg font-bold mb-2">Erro ao buscar produtos</h2>
                <p>Ocorreu um erro ao buscar os produtos. Por favor, tente novamente mais tarde.</p>
              </div>
            ) : sortedProducts.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {sortedProducts.map((product: any) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 p-8 rounded-xl text-center">
                <h2 className="text-xl font-semibold mb-2">Nenhum produto encontrado</h2>
                <p className="text-gray-600 mb-4">
                  Não encontramos produtos que correspondam à sua busca por "{initialQuery}".
                </p>
                <div className="space-y-3">
                  <p className="text-sm text-gray-500">Sugestões:</p>
                  <ul className="text-sm text-gray-600 list-disc list-inside">
                    <li>Verifique a ortografia das palavras</li>
                    <li>Use termos mais genéricos</li>
                    <li>Tente uma nova busca com outras palavras</li>
                  </ul>
                </div>
              </div>
            )}
          </>
        )}

        {/* Initial State - No Search Yet */}
        {!initialQuery && (
          <div className="bg-gray-50 p-8 rounded-xl text-center max-w-2xl mx-auto">
            <SearchIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Busque por produtos</h2>
            <p className="text-gray-600 mb-4">
              Digite o nome, categoria ou características do produto que você está procurando.
            </p>
            <div className="space-y-3 mt-6">
              <p className="text-sm font-medium">Categorias populares:</p>
              <div className="flex flex-wrap justify-center gap-2">
                <Button variant="outline" asChild>
                  <a href="/category/smartphones">Smartphones</a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="/category/audio">Fones de Ouvido</a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="/category/wearables">Smartwatches</a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="/category/accessories">Acessórios</a>
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>
      <Footer />
      <MobileNavbar />
    </>
  );
}
