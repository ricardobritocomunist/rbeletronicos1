import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNavbar from "@/components/layout/MobileNavbar";
import { useAuth } from "@/lib/auth";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { User, Package, CreditCard, Heart, ChevronRight, ShoppingBag } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

// Helper function to format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).format(date);
};

// Helper function for status badge
const OrderStatusBadge = ({ status }: { status: string }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  let label = status;
  
  switch (status) {
    case "pending":
      variant = "secondary";
      label = "Pendente";
      break;
    case "processing":
      variant = "secondary";
      label = "Processando";
      break;
    case "shipped":
      variant = "default";
      label = "Enviado";
      break;
    case "delivered":
      variant = "outline";
      label = "Entregue";
      break;
    case "cancelled":
      variant = "destructive";
      label = "Cancelado";
      break;
  }
  
  return <Badge variant={variant}>{label}</Badge>;
};

export default function Orders() {
  const { isAuthenticated, isLoading } = useAuth();
  const [, navigate] = useLocation();
  
  // Fetch orders
  const { data: orders, isLoading: isLoadingOrders, error } = useQuery({
    queryKey: ["/api/orders"],
    enabled: isAuthenticated,
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login?redirect=/orders");
    }
  }, [isAuthenticated, isLoading, navigate]);

  useEffect(() => {
    document.title = "Meus Pedidos | TechDrop";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Acompanhe o status dos seus pedidos, veja o histórico de compras e rastreie suas encomendas na TechDrop.");
    }
  }, []);

  if (isLoading) {
    return (
      <>
        <Header />
        <main className="container mx-auto px-4 py-8 pb-20 md:pb-8 min-h-[70vh]">
          <div className="flex justify-center items-center h-full">
            <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        </main>
        <Footer />
        <MobileNavbar />
      </>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in the useEffect
  }

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-6">Minha Conta</h1>
        
        <Tabs defaultValue="orders" className="space-y-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full">
            <TabsTrigger value="profile" className="flex items-center" onClick={() => navigate("/profile")}>
              <User className="mr-2 h-4 w-4" />
              <span className="hidden md:inline">Perfil</span>
            </TabsTrigger>
            <TabsTrigger value="orders" className="flex items-center">
              <Package className="mr-2 h-4 w-4" />
              <span className="hidden md:inline">Pedidos</span>
            </TabsTrigger>
            <TabsTrigger value="wishlist" className="flex items-center" onClick={() => navigate("/wishlist")}>
              <Heart className="mr-2 h-4 w-4" />
              <span className="hidden md:inline">Lista de Desejos</span>
            </TabsTrigger>
            <TabsTrigger value="payment" className="flex items-center" onClick={() => navigate("/profile?tab=payment")}>
              <CreditCard className="mr-2 h-4 w-4" />
              <span className="hidden md:inline">Métodos de Pagamento</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>Meus Pedidos</CardTitle>
                <CardDescription>
                  Veja o histórico dos seus pedidos e acompanhe o status das entregas
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingOrders ? (
                  <div className="flex justify-center py-12">
                    <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
                  </div>
                ) : error ? (
                  <div className="text-center py-8">
                    <p className="text-red-500">Erro ao carregar pedidos. Tente novamente mais tarde.</p>
                  </div>
                ) : orders && orders.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Pedido</TableHead>
                          <TableHead>Data</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Total</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {orders.map((order: any) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">#{order.id}</TableCell>
                            <TableCell>{formatDate(order.createdAt)}</TableCell>
                            <TableCell>
                              <OrderStatusBadge status={order.status} />
                            </TableCell>
                            <TableCell>R${Number(order.totalAmount).toFixed(2).replace('.', ',')}</TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm" className="text-primary">
                                Detalhes <ChevronRight className="ml-1 h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <ShoppingBag className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium mb-2">Nenhum pedido encontrado</h3>
                    <p className="text-gray-500 mb-6">
                      Você ainda não fez nenhum pedido em nossa loja.
                    </p>
                    <Button 
                      className="bg-primary hover:bg-primary/90 text-white"
                      onClick={() => navigate("/")}
                    >
                      Começar a Comprar
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      <Footer />
      <MobileNavbar />
    </>
  );
}
