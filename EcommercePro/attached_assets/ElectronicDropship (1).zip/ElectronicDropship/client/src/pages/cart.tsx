import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNavbar from "@/components/layout/MobileNavbar";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent } from "@/components/ui/card";
import CartItem from "@/components/cart/CartItem";
import { ArrowRight, ShoppingCart } from "lucide-react";

export default function Cart() {
  const { cartItems, cartTotal, isLoading } = useCart();
  const [, navigate] = useLocation();

  useEffect(() => {
    document.title = "Carrinho de Compras | TechDrop";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Revise os itens em seu carrinho de compras e prossiga para o checkout.");
    }
  }, []);

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8 min-h-[60vh]">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-2xl md:text-3xl font-bold mb-6">Carrinho de Compras</h1>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : cartItems.length === 0 ? (
            <Card className="mb-8">
              <CardContent className="pt-6 flex flex-col items-center py-12">
                <div className="bg-gray-100 rounded-full p-6 mb-4">
                  <ShoppingCart className="h-16 w-16 text-gray-400" />
                </div>
                <h2 className="text-xl font-semibold mb-2">Seu carrinho está vazio</h2>
                <p className="text-gray-500 text-center mb-6 max-w-md">
                  Parece que você ainda não adicionou nenhum produto ao seu carrinho.
                </p>
                <Button 
                  className="bg-primary hover:bg-primary/90 text-white"
                  onClick={() => navigate("/")}
                >
                  Continuar Comprando
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Card>
                  <CardContent className="p-0">
                    <div className="p-4 border-b bg-gray-50">
                      <h2 className="font-semibold">Detalhes do Pedido</h2>
                    </div>
                    <div className="p-4 space-y-3">
                      {cartItems.map((item) => (
                        <CartItem key={item.id} item={item} />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card className="sticky top-20">
                  <CardContent className="pt-6">
                    <h2 className="font-semibold text-lg mb-4">Resumo do Pedido</h2>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Subtotal</span>
                        <span>R${cartTotal.toFixed(2).replace('.', ',')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Frete</span>
                        <span>R$0,00</span>
                      </div>
                    </div>
                    
                    <Separator className="my-4" />
                    
                    <div className="flex justify-between font-semibold text-lg mb-6">
                      <span>Total</span>
                      <span>R${cartTotal.toFixed(2).replace('.', ',')}</span>
                    </div>
                    
                    <Button 
                      className="w-full bg-primary hover:bg-primary/90 text-white"
                      asChild
                    >
                      <Link href="/checkout">
                        Finalizar Compra <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
      <MobileNavbar />
    </>
  );
}
