import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNavbar from "@/components/layout/MobileNavbar";
import { useAuth } from "@/lib/auth";
import { useCart } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { User, Package, CreditCard, Heart, Trash2, ShoppingCart } from "lucide-react";
import { queryClient } from "@/lib/queryClient";

export default function Wishlist() {
  const { isAuthenticated, isLoading } = useAuth();
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Fetch wishlist items
  const { 
    data: wishlistItems, 
    isLoading: isLoadingWishlist,
    error 
  } = useQuery({
    queryKey: ["/api/wishlist"],
    enabled: isAuthenticated,
  });

  // Remove from wishlist
  const removeFromWishlist = async (id: number) => {
    try {
      await apiRequest("DELETE", `/api/wishlist/${id}`);
      
      // Invalidate wishlist query to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/wishlist"] });
      
      toast({
        title: "Item removido",
        description: "Produto removido da sua lista de desejos",
      });
    } catch (error) {
      console.error("Error removing from wishlist:", error);
      toast({
        title: "Erro",
        description: "Não foi possível remover o produto da lista de desejos",
        variant: "destructive",
      });
    }
  };

  // Add to cart from wishlist
  const handleAddToCart = async (productId: number, wishlistItemId: number) => {
    try {
      await addToCart(productId, 1);
      await removeFromWishlist(wishlistItemId);
    } catch (error) {
      console.error("Error adding to cart from wishlist:", error);
    }
  };

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login?redirect=/wishlist");
    }
  }, [isAuthenticated, isLoading, navigate]);

  useEffect(() => {
    document.title = "Lista de Desejos | TechDrop";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Gerencie sua lista de desejos, salve produtos para comprar mais tarde na TechDrop.");
    }
  }, []);

  if (isLoading) {
    return (
      <>
        <Header />
        <main className="container mx-auto px-4 py-8 pb-20 md:pb-8 min-h-[70vh]">
          <div className="flex justify-center items-center h-full">
            <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        </main>
        <Footer />
        <MobileNavbar />
      </>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in the useEffect
  }

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-6">Minha Conta</h1>
        
        <Tabs defaultValue="wishlist" className="space-y-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full">
            <TabsTrigger value="profile" className="flex items-center" onClick={() => navigate("/profile")}>
              <User className="mr-2 h-4 w-4" />
              <span className="hidden md:inline">Perfil</span>
            </TabsTrigger>
            <TabsTrigger value="orders" className="flex items-center" onClick={() => navigate("/orders")}>
              <Package className="mr-2 h-4 w-4" />
              <span className="hidden md:inline">Pedidos</span>
            </TabsTrigger>
            <TabsTrigger value="wishlist" className="flex items-center">
              <Heart className="mr-2 h-4 w-4" />
              <span className="hidden md:inline">Lista de Desejos</span>
            </TabsTrigger>
            <TabsTrigger value="payment" className="flex items-center" onClick={() => navigate("/profile?tab=payment")}>
              <CreditCard className="mr-2 h-4 w-4" />
              <span className="hidden md:inline">Métodos de Pagamento</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="wishlist">
            <Card>
              <CardHeader>
                <CardTitle>Lista de Desejos</CardTitle>
                <CardDescription>
                  Produtos que você salvou para comprar mais tarde
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingWishlist ? (
                  <div className="flex justify-center py-12">
                    <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
                  </div>
                ) : error ? (
                  <div className="text-center py-8">
                    <p className="text-red-500">Erro ao carregar lista de desejos. Tente novamente mais tarde.</p>
                  </div>
                ) : wishlistItems && wishlistItems.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {wishlistItems.map((item: any) => (
                      <div key={item.id} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all">
                        <div className="relative">
                          <img 
                            src={item.product.imageUrl} 
                            alt={item.product.name} 
                            className="w-full h-48 object-cover"
                            onError={(e) => {
                              e.currentTarget.src = "https://via.placeholder.com/400x300?text=Imagem+Indisponível";
                            }}
                          />
                        </div>
                        <div className="p-4">
                          <h3 className="font-medium mb-1 hover:text-primary truncate">{item.product.name}</h3>
                          <p className="text-gray-500 text-sm mb-2 line-clamp-2">{item.product.description}</p>
                          <div className="flex justify-between items-center">
                            <p className="font-semibold text-lg">
                              R${Number(item.product.price).toFixed(2).replace('.', ',')}
                            </p>
                            <div className="flex space-x-2">
                              <Button
                                variant="outline"
                                size="icon"
                                className="text-gray-400 hover:text-red-500"
                                onClick={() => removeFromWishlist(item.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                              <Button
                                size="icon"
                                className="bg-primary hover:bg-primary/90 text-white"
                                onClick={() => handleAddToCart(item.product.id, item.id)}
                                disabled={item.product.stock <= 0}
                              >
                                <ShoppingCart className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Heart className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium mb-2">Lista de desejos vazia</h3>
                    <p className="text-gray-500 mb-6">
                      Você ainda não adicionou nenhum produto à sua lista de desejos.
                    </p>
                    <Button 
                      className="bg-primary hover:bg-primary/90 text-white"
                      onClick={() => navigate("/")}
                    >
                      Explorar Produtos
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      <Footer />
      <MobileNavbar />
    </>
  );
}
