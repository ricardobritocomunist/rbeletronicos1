import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import {
  Heart,
  Share2,
  ShoppingCart,
  ChevronLeft,
  ChevronRight,
  Truck,
  ShieldCheck,
  CreditCard,
  Plus,
  Minus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import StarRating from "@/components/ui/star-rating";
import ProductSection from "@/components/ProductSection";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useCart } from "@/context/CartContext";
import { formatCurrency, calculateDiscount } from "@/lib/utils";

const ProductDetail = () => {
  const { slug } = useParams();
  const [, navigate] = useLocation();
  const [quantity, setQuantity] = useState(1);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const { addToCart } = useCart();

  // Fetch product details
  const { data: product, isLoading, error } = useQuery({
    queryKey: [`/api/products/${slug}`],
  });

  // Fetch category
  const { data: category } = useQuery({
    queryKey: [product ? `/api/categories/${product.categoryId}` : null],
    enabled: !!product?.categoryId,
  });

  const handleAddToCart = () => {
    if (product) {
      addToCart(product.id, quantity);
    }
  };

  const increaseQuantity = () => {
    setQuantity((prev) => prev + 1);
  };

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity((prev) => prev - 1);
    }
  };

  // Handle next/prev images
  const handleNextImage = () => {
    if (product?.images && product.images.length > 0) {
      setActiveImageIndex((prev) => 
        prev === product.images.length ? 0 : prev + 1
      );
    }
  };

  const handlePrevImage = () => {
    if (product?.images && product.images.length > 0) {
      setActiveImageIndex((prev) => 
        prev === 0 ? product.images.length - 1 : prev - 1
      );
    }
  };

  // If product not found
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <h1 className="text-2xl font-bold mb-4">Produto não encontrado</h1>
        <p className="text-gray-600 mb-6">
          O produto que você está procurando não existe ou foi removido.
        </p>
        <Button onClick={() => navigate("/products")}>
          Ver todos os produtos
        </Button>
      </div>
    );
  }

  // Get product images array
  const productImages = product?.images?.length 
    ? [product.image, ...product.images] 
    : [product?.image];

  // Calculate discount if applicable
  const discountPercentage = product?.compareAtPrice 
    ? calculateDiscount(product.compareAtPrice, product.price) 
    : 0;

  return (
    <>
      {/* SEO metadata */}
      <Helmet>
        <title>{product ? `${product.name} | TechDrop` : "Carregando produto..."}</title>
        <meta
          name="description"
          content={product?.description || "Carregando detalhes do produto..."}
        />
      </Helmet>

      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-gray-500 mb-4">
        <Button
          variant="link"
          className="p-0 h-auto font-normal text-gray-500"
          onClick={() => navigate("/")}
        >
          Início
        </Button>
        <span className="mx-2">/</span>
        {category ? (
          <>
            <Button
              variant="link"
              className="p-0 h-auto font-normal text-gray-500"
              onClick={() => navigate(`/products/category/${category.slug}`)}
            >
              {category.name}
            </Button>
            <span className="mx-2">/</span>
          </>
        ) : null}
        <span className="text-gray-800 font-medium">
          {product?.name || "Carregando..."}
        </span>
      </div>

      {/* Product Content */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
          {/* Product Images */}
          <div>
            {isLoading ? (
              <Skeleton className="w-full aspect-square rounded-lg" />
            ) : (
              <div className="relative aspect-square rounded-lg overflow-hidden bg-gray-100">
                <img
                  src={productImages[activeImageIndex]}
                  alt={product?.name}
                  className="w-full h-full object-cover"
                />

                {productImages.length > 1 && (
                  <>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full"
                      onClick={handlePrevImage}
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full"
                      onClick={handleNextImage}
                    >
                      <ChevronRight className="h-5 w-5" />
                    </Button>
                  </>
                )}

                {product?.isNew && (
                  <Badge className="absolute top-2 left-2 bg-accent text-white">
                    Novo
                  </Badge>
                )}
                {discountPercentage > 0 && (
                  <Badge className="absolute top-2 right-2 bg-secondary text-white">
                    -{discountPercentage}%
                  </Badge>
                )}
              </div>
            )}

            {/* Thumbnail Images */}
            {!isLoading && productImages.length > 1 && (
              <div className="grid grid-cols-5 gap-2 mt-4">
                {productImages.map((image, index) => (
                  <button
                    key={index}
                    className={`aspect-square rounded-md overflow-hidden border-2 ${
                      activeImageIndex === index
                        ? "border-primary"
                        : "border-transparent"
                    }`}
                    onClick={() => setActiveImageIndex(index)}
                  >
                    <img
                      src={image}
                      alt={`${product?.name} - Imagem ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-8 w-3/4" />
                <Skeleton className="h-4 w-1/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-10 w-1/3" />
                <Skeleton className="h-12 w-full mt-6" />
              </div>
            ) : (
              <>
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                  {product?.name}
                </h1>

                <div className="flex items-center mb-4">
                  <StarRating rating={product?.rating || 0} reviews={product?.numReviews} size="md" />
                </div>

                <p className="text-gray-600 mb-6">{product?.description}</p>

                <div className="mb-6">
                  {product?.compareAtPrice && (
                    <span className="text-gray-500 line-through mr-2">
                      {formatCurrency(product.compareAtPrice)}
                    </span>
                  )}
                  <span className="text-3xl font-bold text-gray-900">
                    {formatCurrency(product?.price || 0)}
                  </span>
                  {product?.inStock ? (
                    <Badge className="ml-3 bg-accent">Em estoque</Badge>
                  ) : (
                    <Badge className="ml-3 bg-gray-500">Indisponível</Badge>
                  )}
                </div>

                {/* Quantity Selector */}
                <div className="flex items-center mb-6">
                  <span className="text-gray-700 mr-4">Quantidade:</span>
                  <div className="flex items-center border border-gray-300 rounded-md">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-10 w-10 rounded-none border-r border-gray-300"
                      onClick={decreaseQuantity}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <div className="h-10 w-12 flex items-center justify-center">
                      {quantity}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-10 w-10 rounded-none border-l border-gray-300"
                      onClick={increaseQuantity}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 mb-6">
                  <Button
                    className="bg-primary hover:bg-primary/90 text-white py-3 px-8 rounded-lg font-medium flex-1"
                    size="lg"
                    onClick={handleAddToCart}
                    disabled={!product?.inStock}
                  >
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Adicionar ao Carrinho
                  </Button>
                  <Button
                    variant="outline"
                    className="py-3 px-8 rounded-lg font-medium"
                    size="lg"
                  >
                    <Heart className="mr-2 h-5 w-5" />
                    Favorito
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="hidden sm:flex h-12 w-12 rounded-lg"
                  >
                    <Share2 className="h-5 w-5" />
                  </Button>
                </div>

                {/* Shipping & Payment Info */}
                <div className="space-y-3 border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center text-gray-700">
                    <Truck className="h-5 w-5 mr-3 text-primary" />
                    <span>Envio para todo o Brasil</span>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <ShieldCheck className="h-5 w-5 mr-3 text-primary" />
                    <span>Garantia de 12 meses</span>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <CreditCard className="h-5 w-5 mr-3 text-primary" />
                    <span>Pagamento seguro via Stripe</span>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Product Details Tabs */}
        {!isLoading && (
          <div className="px-6 pb-6">
            <Tabs defaultValue="details">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="details">Detalhes</TabsTrigger>
                <TabsTrigger value="specs">Especificações</TabsTrigger>
                <TabsTrigger value="reviews">Avaliações</TabsTrigger>
              </TabsList>
              <TabsContent value="details" className="p-4">
                <p className="text-gray-700">{product?.description}</p>
              </TabsContent>
              <TabsContent value="specs" className="p-4">
                {product?.specs ? (
                  <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
                    {Object.entries(product.specs).map(([key, value]) => (
                      <div key={key} className="flex border-b border-gray-100 pb-2">
                        <dt className="w-1/3 font-medium text-gray-500 capitalize">
                          {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:
                        </dt>
                        <dd className="w-2/3 text-gray-900">{value}</dd>
                      </div>
                    ))}
                  </dl>
                ) : (
                  <p className="text-gray-500">Nenhuma especificação disponível.</p>
                )}
              </TabsContent>
              <TabsContent value="reviews" className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">
                    {product?.numReviews || 0} Avaliações
                  </h3>
                  <div className="flex items-center">
                    <StarRating rating={product?.rating || 0} size="md" showReviews={false} />
                    <span className="ml-2 text-lg font-medium">{product?.rating || 0}/5</span>
                  </div>
                </div>
                <Separator className="my-4" />
                <p className="text-gray-500 text-center py-6">Avaliações serão implementadas em breve.</p>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>

      {/* Related Products */}
      {!isLoading && category && (
        <ProductSection
          title="Produtos Relacionados"
          endpoint={`/api/products?category=${category.slug}&limit=4`}
          viewAllLink={`/products/category/${category.slug}`}
        />
      )}
    </>
  );
};

export default ProductDetail;
