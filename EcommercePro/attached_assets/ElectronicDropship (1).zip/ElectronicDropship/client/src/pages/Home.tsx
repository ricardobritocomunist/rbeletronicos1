import { Helmet } from "react-helmet";
import HeroSlider from "@/components/HeroSlider";
import Features from "@/components/Features";
import Newsletter from "@/components/Newsletter";
import PromoBanner from "@/components/PromoBanner";
import ProductSection from "@/components/ProductSection";
import { useQuery } from "@tanstack/react-query";
import CategoryCard from "@/components/ui/category-card";

const Home = () => {
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });

  return (
    <>
      <Helmet>
        <title>TechDrop - Loja de Eletrônicos Online</title>
        <meta
          name="description"
          content="TechDrop - Loja online de eletrônicos com os melhores preços. Smartphones, fones de ouvido, smartwatches, acessórios e muito mais."
        />
      </Helmet>

      {/* Hero Slider */}
      <HeroSlider />

      {/* Featured Categories */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-6">Categorias em Destaque</h2>
        {categories ? (
          <div className="category-grid">
            {categories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div
                key={i}
                className="bg-gray-200 rounded-xl h-40 animate-pulse"
              ></div>
            ))}
          </div>
        )}
      </section>

      {/* Best Sellers */}
      <ProductSection
        title="Produtos Mais Vendidos"
        endpoint="/api/products?featured=true&limit=4"
        viewAllLink="/products?featured=true"
      />

      {/* Promo Banner */}
      <PromoBanner
        title="Até 30% de desconto em acessórios para smartphones"
        description="Aproveite preços especiais em capas, carregadores, películas e muito mais. Oferta por tempo limitado!"
        label="Oferta Exclusiva"
        link="/products/category/accessories"
        image="https://images.unsplash.com/photo-1491933382434-500287f9b54b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500"
      />

      {/* New Arrivals */}
      <ProductSection
        title="Novidades"
        endpoint="/api/products?new=true&limit=4"
        viewAllLink="/products?new=true"
      />

      {/* Features */}
      <Features />

      {/* Newsletter */}
      <Newsletter />
    </>
  );
};

export default Home;
