import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/context/AuthContext";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { registerSchema } from "@/lib/validators";
import { BoltIcon, UserPlus } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

type FormData = z.infer<typeof registerSchema>;

const Register = () => {
  const [location, navigate] = useLocation();
  const { register: registerUser, isAuthenticated, isLoading } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get redirect URL from query params
  const params = new URLSearchParams(location.split("?")[1]);
  const redirectUrl = params.get("redirect") || "/";
  
  const form = useForm<FormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      name: "",
    },
  });
  
  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated && !isLoading) {
      navigate(redirectUrl);
    }
  }, [isAuthenticated, isLoading, navigate, redirectUrl]);
  
  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      const success = await registerUser(data);
      if (success) {
        navigate("/login" + (redirectUrl !== "/" ? `?redirect=${encodeURIComponent(redirectUrl)}` : ""));
      }
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Show loading while checking auth state
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  // Don't show register form if already authenticated
  if (isAuthenticated) {
    return null;
  }
  
  return (
    <>
      <Helmet>
        <title>Cadastro | TechDrop</title>
        <meta
          name="description"
          content="Crie sua conta na TechDrop para uma melhor experiência de compra, acompanhamento de pedidos e acesso a ofertas exclusivas."
        />
      </Helmet>
      
      <div className="flex justify-center py-8">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <div className="flex justify-center mb-4">
              <div className="flex items-center space-x-2">
                <BoltIcon className="text-primary h-8 w-8" />
                <span className="text-2xl font-bold text-neutral-dark">Tech<span className="text-primary">Drop</span></span>
              </div>
            </div>
            <CardTitle className="text-2xl text-center">Criar uma conta</CardTitle>
            <CardDescription className="text-center">
              Preencha os dados abaixo para se cadastrar
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome completo</FormLabel>
                      <FormControl>
                        <Input placeholder="Digite seu nome completo" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="Digite seu email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome de usuário</FormLabel>
                      <FormControl>
                        <Input placeholder="Digite seu nome de usuário" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Digite sua senha" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/90"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <span className="flex items-center">
                      <span className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
                      Cadastrando...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <UserPlus className="mr-2 h-5 w-5" />
                      Cadastrar
                    </span>
                  )}
                </Button>
              </form>
            </Form>
            
            <Separator />
            
            <div className="text-center">
              <p className="text-sm text-gray-600">
                Já tem uma conta?{" "}
                <Link 
                  href={redirectUrl ? `/login?redirect=${encodeURIComponent(redirectUrl)}` : "/login"} 
                  className="text-primary hover:underline font-medium"
                >
                  Faça login
                </Link>
              </p>
            </div>
            
            <div className="text-xs text-gray-500 text-center mt-4">
              Ao se cadastrar, você concorda com nossos Termos de Serviço e Política de Privacidade.
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default Register;
