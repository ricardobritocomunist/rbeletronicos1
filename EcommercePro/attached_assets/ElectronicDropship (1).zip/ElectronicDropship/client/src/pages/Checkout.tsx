import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { shippingAddressSchema } from "@/lib/validators";
import { CheckCircle, CreditCard, ArrowLeft, Building2, Truck, Package } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  console.warn('Missing Stripe public key: VITE_STRIPE_PUBLIC_KEY');
}

const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY) 
  : null;

type FormData = z.infer<typeof shippingAddressSchema>;

const CheckoutForm = ({ shippingAddress, onSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { clearCart } = useCart();
  const [, navigate] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsLoading(true);

    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin + '/orders',
        },
        redirect: 'if_required',
      });

      if (error) {
        toast({
          title: "Erro no pagamento",
          description: error.message,
          variant: "destructive",
        });
      } else if (paymentIntent.status === 'succeeded') {
        // Payment succeeded, create order
        const response = await apiRequest("POST", "/api/checkout", {
          shippingAddress,
          paymentMethod: "credit_card",
          paymentId: paymentIntent.id,
        });

        if (response.ok) {
          const data = await response.json();
          toast({
            title: "Pedido realizado com sucesso!",
            description: "Seu pedido foi confirmado e está sendo processado.",
          });
          clearCart();
          onSuccess(data.orderId);
        } else {
          throw new Error("Failed to create order");
        }
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast({
        title: "Erro no pagamento",
        description: "Ocorreu um erro ao processar seu pagamento. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="p-4 border border-gray-200 rounded-lg">
        <PaymentElement />
      </div>
      
      <Button
        type="submit"
        className="w-full bg-primary hover:bg-primary/90"
        size="lg"
        disabled={!stripe || isLoading}
      >
        {isLoading ? (
          <span className="flex items-center">
            <span className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
            Processando...
          </span>
        ) : (
          <span className="flex items-center">
            <CreditCard className="mr-2 h-5 w-5" />
            Finalizar Pagamento
          </span>
        )}
      </Button>
    </form>
  );
};

const CheckoutSuccess = ({ orderId }) => {
  const [, navigate] = useLocation();

  return (
    <div className="text-center py-10">
      <div className="bg-green-100 inline-flex rounded-full p-6 mb-4">
        <CheckCircle className="h-12 w-12 text-green-600" />
      </div>
      <h2 className="text-2xl font-semibold mb-2">Pedido Confirmado!</h2>
      <p className="text-gray-600 mb-6">
        Seu pedido #{orderId} foi processado com sucesso. Você receberá um email com os detalhes.
      </p>
      <div className="flex flex-col sm:flex-row justify-center gap-3">
        <Button 
          variant="outline" 
          className="px-6"
          onClick={() => navigate("/orders")}
        >
          Ver Meus Pedidos
        </Button>
        <Button 
          className="bg-primary hover:bg-primary/90 px-6"
          onClick={() => navigate("/products")}
        >
          Continuar Comprando
        </Button>
      </div>
    </div>
  );
};

const Checkout = () => {
  const [step, setStep] = useState(1);
  const [shippingAddress, setShippingAddress] = useState<FormData | null>(null);
  const [clientSecret, setClientSecret] = useState("");
  const [orderId, setOrderId] = useState<number | null>(null);
  const { cartItems, isLoading: isCartLoading } = useCart();
  const { user, isAuthenticated, isLoading: isAuthLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Define form with validation
  const form = useForm<FormData>({
    resolver: zodResolver(shippingAddressSchema),
    defaultValues: {
      name: user?.name || "",
      address: user?.address || "",
      city: user?.city || "",
      state: user?.state || "",
      postalCode: user?.postalCode || "",
      country: user?.country || "Brasil",
      phone: user?.phone || "",
    },
  });

  // Update form values when user data loads
  useEffect(() => {
    if (user) {
      form.reset({
        name: user.name || "",
        address: user.address || "",
        city: user.city || "",
        state: user.state || "",
        postalCode: user.postalCode || "",
        country: user.country || "Brasil",
        phone: user.phone || "",
      });
    }
  }, [user, form]);

  // Calculate totals
  const subtotal = cartItems.reduce(
    (total, item) => total + item.product.price * item.cartItem.quantity,
    0
  );
  const shippingCost = subtotal > 199 ? 0 : 15.9;
  const total = subtotal + shippingCost;

  // Redirect if not authenticated or cart is empty
  useEffect(() => {
    if (!isAuthLoading && !isAuthenticated) {
      navigate("/login?redirect=/checkout");
    } else if (!isCartLoading && cartItems.length === 0) {
      navigate("/cart");
    }
  }, [isAuthLoading, isAuthenticated, isCartLoading, cartItems, navigate]);

  // Submit shipping address and go to payment step
  const onSubmitShippingAddress = async (data: FormData) => {
    setShippingAddress(data);
    
    try {
      // Create payment intent
      const response = await apiRequest("POST", "/api/create-payment-intent", {
        amount: total
      });
      
      if (!response.ok) {
        throw new Error("Failed to create payment intent");
      }
      
      const data = await response.json();
      setClientSecret(data.clientSecret);
      setStep(2);
    } catch (error) {
      console.error("Error creating payment intent:", error);
      toast({
        title: "Erro no checkout",
        description: "Não foi possível iniciar o processo de pagamento. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  // Handle successful payment and order creation
  const handleSuccess = (newOrderId: number) => {
    setOrderId(newOrderId);
    setStep(3);
  };

  // If not authenticated or cart is empty, show loading
  if (isAuthLoading || isCartLoading || (cartItems.length === 0 && step !== 3)) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Checkout | TechDrop</title>
        <meta
          name="description"
          content="Finalize sua compra de forma segura na TechDrop. Vários métodos de pagamento disponíveis."
        />
      </Helmet>

      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-10">
        <div className="p-6">
          {step === 1 && (
            <>
              <div className="flex items-center mb-6">
                <Button
                  variant="ghost"
                  size="sm"
                  className="mr-2"
                  onClick={() => navigate("/cart")}
                >
                  <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
                </Button>
                <h1 className="text-2xl font-bold">Informações de Entrega</h1>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <Form {...form}>
                    <form
                      onSubmit={form.handleSubmit(onSubmitShippingAddress)}
                      className="space-y-4"
                    >
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome Completo</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Seu nome completo"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Endereço</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Rua, número, complemento"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="city"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Cidade</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Sua cidade"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="state"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estado</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Seu estado"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="postalCode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>CEP</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="00000-000"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="country"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>País</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Seu país"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Telefone</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="(00) 00000-0000"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button
                        type="submit"
                        className="w-full bg-primary hover:bg-primary/90 mt-4"
                        size="lg"
                      >
                        Continuar para Pagamento
                      </Button>
                    </form>
                  </Form>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg h-fit">
                  <h2 className="text-lg font-semibold mb-4">Resumo do Pedido</h2>
                  
                  <div className="mb-4">
                    {cartItems.map((item) => (
                      <div key={item.cartItem.id} className="flex justify-between py-2">
                        <div className="flex">
                          <span className="font-medium">
                            {item.cartItem.quantity}x
                          </span>
                          <span className="ml-2 text-gray-700 line-clamp-1">
                            {item.product.name}
                          </span>
                        </div>
                        <span>
                          {formatCurrency(item.product.price * item.cartItem.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3 pt-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal</span>
                      <span>{formatCurrency(subtotal)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600">Frete</span>
                      <span>
                        {shippingCost === 0 ? (
                          <span className="text-green-600 font-medium">Grátis</span>
                        ) : (
                          formatCurrency(shippingCost)
                        )}
                      </span>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex justify-between font-semibold text-lg">
                      <span>Total</span>
                      <span>{formatCurrency(total)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {step === 2 && shippingAddress && clientSecret && stripePromise && (
            <>
              <div className="flex items-center mb-6">
                <Button
                  variant="ghost"
                  size="sm"
                  className="mr-2"
                  onClick={() => setStep(1)}
                >
                  <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
                </Button>
                <h1 className="text-2xl font-bold">Pagamento</h1>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <Elements 
                    stripe={stripePromise} 
                    options={{ clientSecret, appearance: { theme: 'stripe' } }}
                  >
                    <CheckoutForm 
                      shippingAddress={shippingAddress} 
                      onSuccess={handleSuccess}
                    />
                  </Elements>
                </div>

                <div className="space-y-4">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h2 className="text-lg font-semibold mb-4">Resumo do Pedido</h2>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Subtotal</span>
                        <span>{formatCurrency(subtotal)}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-gray-600">Frete</span>
                        <span>
                          {shippingCost === 0 ? "Grátis" : formatCurrency(shippingCost)}
                        </span>
                      </div>
                      
                      <Separator />
                      
                      <div className="flex justify-between font-semibold text-lg">
                        <span>Total</span>
                        <span>{formatCurrency(total)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold mb-3">Endereço de Entrega</h3>
                    <p className="text-gray-700">{shippingAddress.name}</p>
                    <p className="text-gray-700">{shippingAddress.address}</p>
                    <p className="text-gray-700">
                      {shippingAddress.city}, {shippingAddress.state} - {shippingAddress.postalCode}
                    </p>
                    <p className="text-gray-700">{shippingAddress.country}</p>
                    <p className="text-gray-700">{shippingAddress.phone}</p>
                  </div>
                </div>
              </div>
            </>
          )}

          {step === 3 && orderId && (
            <CheckoutSuccess orderId={orderId} />
          )}
        </div>
      </div>
    </>
  );
};

export default Checkout;
