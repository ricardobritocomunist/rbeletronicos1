import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNavbar from "@/components/layout/MobileNavbar";
import Hero from "@/components/home/Hero";
import FeaturedCategories from "@/components/home/FeaturedCategories";
import BestSellers from "@/components/home/BestSellers";
import PromoBanner from "@/components/home/PromoBanner";
import NewArrivals from "@/components/home/NewArrivals";
import Features from "@/components/home/Features";
import Newsletter from "@/components/home/Newsletter";
import { useEffect } from "react";

export default function Home() {
  useEffect(() => {
    // Set page title and meta tags for SEO
    document.title = "TechDrop - Loja de Eletrônicos Online";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "TechDrop - Loja online de eletrônicos com os melhores preços para dropshipping. Smartphones, fones de ouvido, smartwatches e muito mais!");
    }
  }, []);

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
        <Hero />
        <FeaturedCategories />
        <BestSellers />
        <PromoBanner />
        <NewArrivals />
        <Features />
        <Newsletter />
      </main>
      <Footer />
      <MobileNavbar />
    </>
  );
}
