import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Package, ChevronRight, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { formatDate, formatCurrency } from "@/lib/utils";

// Order status badge color mapping
const statusColors = {
  pending: "bg-yellow-500",
  processing: "bg-blue-500",
  shipped: "bg-purple-500",
  delivered: "bg-green-500",
  cancelled: "bg-red-500",
};

// Order status human-readable labels
const statusLabels = {
  pending: "Pendente",
  processing: "Processando",
  shipped: "Enviado",
  delivered: "Entregue",
  cancelled: "Cancelado",
};

const OrderHistory = () => {
  const [, navigate] = useLocation();
  const { isAuthenticated, isLoading } = useAuth();
  
  // Fetch user orders
  const { data: orders, isLoading: isOrdersLoading } = useQuery({
    queryKey: ["/api/orders"],
    enabled: isAuthenticated,
  });
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      navigate("/login?redirect=/orders");
    }
  }, [isAuthenticated, isLoading, navigate]);
  
  // Show loading while checking auth state or fetching orders
  if (isLoading || isOrdersLoading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Histórico de Pedidos | TechDrop</title>
        <meta
          name="description"
          content="Acompanhe seus pedidos anteriores e verifique o status de entrega na TechDrop."
        />
      </Helmet>
      
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-6 flex items-center">
          <Package className="mr-2 h-7 w-7" /> Meus Pedidos
        </h1>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Histórico de Pedidos</CardTitle>
            <CardDescription>
              Visualize e acompanhe todos os seus pedidos anteriores.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {orders?.length ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pedido</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">#{order.id}</TableCell>
                      <TableCell>{formatDate(order.createdAt)}</TableCell>
                      <TableCell>{formatCurrency(order.total)}</TableCell>
                      <TableCell>
                        <Badge className={`${statusColors[order.status] || "bg-gray-500"}`}>
                          {statusLabels[order.status] || order.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="h-8"
                          onClick={() => navigate(`/orders/${order.id}`)}
                        >
                          Detalhes <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Nenhum pedido encontrado</AlertTitle>
                <AlertDescription>
                  Você ainda não fez nenhum pedido.
                  <Button 
                    variant="link" 
                    className="p-0 h-auto font-normal ml-2"
                    onClick={() => navigate("/products")}
                  >
                    Comece a comprar agora
                  </Button>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
        
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={() => navigate("/profile")}
          >
            Voltar para o Perfil
          </Button>
          <Button 
            onClick={() => navigate("/products")}
            className="bg-primary hover:bg-primary/90"
          >
            Continuar Comprando
          </Button>
        </div>
      </div>
    </>
  );
};

export default OrderHistory;
