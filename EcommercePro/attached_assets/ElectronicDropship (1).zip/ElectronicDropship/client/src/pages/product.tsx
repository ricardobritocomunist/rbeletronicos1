import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNavbar from "@/components/layout/MobileNavbar";
import { useCart } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Heart, 
  ShoppingCart,
  Star,
  StarHalf,
  Share2,
  Truck,
  ChevronRight,
  ShieldCheck,
  RefreshCw
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import ProductCard from "@/components/product/ProductCard";

export default function Product() {
  const [, params] = useRoute("/product/:slug");
  const slug = params?.slug;
  const { toast } = useToast();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  const { data: product, isLoading: isLoadingProduct, error: productError } = useQuery({
    queryKey: [`/api/products/${slug}`],
    enabled: !!slug,
  });

  const { data: relatedProducts, isLoading: isLoadingRelated } = useQuery({
    queryKey: ["/api/products", product?.categoryId],
    enabled: !!product?.categoryId,
  });

  const handleAddToCart = async () => {
    if (!product) return;
    
    setIsAddingToCart(true);
    try {
      await addToCart(product.id, quantity);
    } catch (error) {
      console.error("Error adding to cart:", error);
    } finally {
      setIsAddingToCart(false);
    }
  };

  const handleAddToWishlist = () => {
    toast({
      title: "Adicionado aos favoritos",
      description: "Produto adicionado à sua lista de desejos",
    });
  };

  // Helper function to render stars based on rating
  const renderRatingStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-yellow-400 text-yellow-400" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="fill-yellow-400 text-yellow-400" />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-star-${i}`} className="text-gray-300" />);
    }
    
    return stars;
  };

  useEffect(() => {
    if (product) {
      document.title = `${product.name} | TechDrop`;
      
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute("content", product.description || `Compre ${product.name} na TechDrop. Envio rápido, garantia e os melhores preços.`);
      }
    }
  }, [product]);

  if (productError) {
    return (
      <>
        <Header />
        <main className="container mx-auto px-4 py-10 min-h-[60vh]">
          <div className="bg-red-50 text-red-500 p-6 rounded-lg">
            <h2 className="text-xl font-bold mb-2">Produto não encontrado</h2>
            <p>O produto que você está procurando não está disponível ou foi removido.</p>
            <Button className="mt-4 bg-primary text-white" asChild>
              <a href="/">Voltar para a página inicial</a>
            </Button>
          </div>
        </main>
        <Footer />
        <MobileNavbar />
      </>
    );
  }

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
          {/* Product Image */}
          <div className="bg-white p-4 rounded-xl shadow-md">
            {isLoadingProduct ? (
              <Skeleton className="w-full aspect-square rounded-lg" />
            ) : (
              <img 
                src={product.imageUrl} 
                alt={product.name} 
                className="w-full object-contain rounded-lg"
                style={{ maxHeight: "500px" }}
                onError={(e) => {
                  e.currentTarget.src = "https://via.placeholder.com/500?text=Imagem+Indisponível";
                }}
              />
            )}
          </div>

          {/* Product Details */}
          <div>
            {isLoadingProduct ? (
              <div className="space-y-4">
                <Skeleton className="h-8 w-3/4" />
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map(i => (
                    <Skeleton key={i} className="h-4 w-4" />
                  ))}
                  <Skeleton className="h-4 w-10 ml-2" />
                </div>
                <Skeleton className="h-10 w-40" />
                <Skeleton className="h-24 w-full" />
                <div className="py-4">
                  <Skeleton className="h-10 w-full" />
                </div>
                <div className="flex space-x-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-12" />
                </div>
              </div>
            ) : (
              <>
                <h1 className="text-2xl md:text-3xl font-bold mb-2">{product.name}</h1>
                <div className="flex items-center space-x-1 mb-3">
                  {renderRatingStars(product.rating)}
                  <span className="text-gray-500 ml-1">({product.numReviews} avaliações)</span>
                </div>
                
                <div className="mb-5">
                  {product.compareAtPrice && (
                    <p className="text-gray-500 line-through">
                      R${product.compareAtPrice.toFixed(2).replace('.', ',')}
                    </p>
                  )}
                  <p className="text-3xl font-bold text-neutral-dark">
                    R${product.price.toFixed(2).replace('.', ',')}
                  </p>
                  <p className="text-sm text-gray-500">À vista ou em até 12x sem juros</p>
                </div>
                
                <div className="mb-6">
                  <p className="text-gray-700">{product.description}</p>
                </div>

                <Separator className="my-5" />
                
                <div className="flex items-center space-x-3 mb-6">
                  <div className="flex items-center border rounded-lg">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-10 w-10"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                    >
                      -
                    </Button>
                    <span className="px-3">{quantity}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-10 w-10"
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      disabled={quantity >= product.stock}
                    >
                      +
                    </Button>
                  </div>
                  
                  <p className="text-sm text-gray-600">
                    {product.stock} {product.stock === 1 ? 'unidade' : 'unidades'} disponíveis
                  </p>
                </div>
                
                <div className="flex space-x-3 mb-6">
                  <Button 
                    className="flex-1 bg-primary hover:bg-primary/90 text-white py-6"
                    onClick={handleAddToCart}
                    disabled={isAddingToCart || product.stock <= 0}
                  >
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    {product.stock <= 0 ? "Sem estoque" : "Adicionar ao Carrinho"}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="p-6"
                    onClick={handleAddToWishlist}
                  >
                    <Heart className="h-5 w-5" />
                  </Button>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center text-gray-700">
                    <Truck className="h-5 w-5 mr-2 text-primary" />
                    <span>Envio rápido para todo o Brasil</span>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <ShieldCheck className="h-5 w-5 mr-2 text-primary" />
                    <span>Garantia de 12 meses do fabricante</span>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <RefreshCw className="h-5 w-5 mr-2 text-primary" />
                    <span>30 dias para devolução</span>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Related Products */}
        {!isLoadingProduct && (
          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-6">Produtos Relacionados</h2>
            
            {isLoadingRelated ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="h-64 rounded-xl" />
                ))}
              </div>
            ) : relatedProducts?.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {relatedProducts
                  .filter((related: any) => related.id !== product.id)
                  .slice(0, 4)
                  .map((relatedProduct: any) => (
                    <ProductCard key={relatedProduct.id} product={relatedProduct} />
                  ))}
              </div>
            ) : (
              <p className="text-gray-500">Nenhum produto relacionado encontrado</p>
            )}
          </section>
        )}
      </main>
      <Footer />
      <MobileNavbar />
    </>
  );
}
