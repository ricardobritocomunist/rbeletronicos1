import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import AdminLayout from "@/components/admin/AdminLayout";
import DashboardCard from "@/components/admin/DashboardCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DollarSign,
  Package,
  ShoppingCart,
  Users,
  TrendingUp,
  TrendingDown,
  Activity
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

export default function AdminDashboard() {
  const [, navigate] = useLocation();

  // Fetch products
  const { data: products, isLoading: isLoadingProducts } = useQuery({
    queryKey: ["/api/products"],
  });

  // Fetch orders
  const { data: orders, isLoading: isLoadingOrders } = useQuery({
    queryKey: ["/api/orders"],
  });

  // Fetch users
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
  });

  useEffect(() => {
    document.title = "Dashboard | Admin TechDrop";
  }, []);

  // Calculate total revenue from orders
  const totalRevenue = orders
    ? orders.reduce((sum: number, order: any) => sum + Number(order.totalAmount), 0)
    : 0;

  // Generate sample data for charts based on real orders
  const generateSalesData = () => {
    if (!orders) return [];

    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toISOString().slice(0, 10);
    }).reverse();

    return last7Days.map(date => {
      const dayOrders = orders.filter((order: any) => 
        order.createdAt.slice(0, 10) === date
      );
      
      const revenue = dayOrders.reduce(
        (sum: number, order: any) => sum + Number(order.totalAmount), 
        0
      );

      return {
        name: new Date(date).toLocaleDateString('pt-BR', { weekday: 'short' }),
        vendas: dayOrders.length,
        receita: revenue,
      };
    });
  };

  const salesData = generateSalesData();

  // Generate data for category distribution
  const generateCategoryData = () => {
    if (!products) return [];

    const categories: Record<string, number> = {};
    
    products.forEach((product: any) => {
      const categoryId = product.categoryId;
      if (categoryId) {
        categories[categoryId] = (categories[categoryId] || 0) + 1;
      }
    });

    // Map category IDs to more presentable names
    const categoryLabels: Record<number, string> = {
      1: "Smartphones",
      2: "Audio",
      3: "Wearables",
      4: "Acessórios",
      5: "Tablets",
      6: "Laptops",
      7: "Gadgets",
    };

    return Object.entries(categories).map(([id, count]) => ({
      name: categoryLabels[Number(id)] || `Categoria ${id}`,
      value: count,
    }));
  };

  const categoryData = generateCategoryData();
  
  // Generate data for order status distribution
  const generateOrderStatusData = () => {
    if (!orders) return [];

    const statuses: Record<string, number> = {};
    
    orders.forEach((order: any) => {
      const status = order.status;
      statuses[status] = (statuses[status] || 0) + 1;
    });

    // Map status to more presentable labels
    const statusLabels: Record<string, string> = {
      "pending": "Pendente",
      "processing": "Processando",
      "shipped": "Enviado",
      "delivered": "Entregue",
      "cancelled": "Cancelado"
    };

    return Object.entries(statuses).map(([status, count]) => ({
      name: statusLabels[status] || status,
      value: count,
    }));
  };

  const orderStatusData = generateOrderStatusData();

  // Colors for pie charts
  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

  return (
    <AdminLayout title="Dashboard">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <DashboardCard
          title="Receita Total"
          value={isLoadingOrders ? "Carregando..." : `R$${totalRevenue.toFixed(2).replace(".", ",")}`}
          description="Total de receita"
          icon={<DollarSign className="h-4 w-4" />}
          trend={orders ? { value: 12.5, isPositive: true } : undefined}
          onClick={() => navigate("/admin/orders")}
        />
        
        <DashboardCard
          title="Pedidos"
          value={isLoadingOrders ? "Carregando..." : orders.length}
          description="Total de pedidos"
          icon={<ShoppingCart className="h-4 w-4" />}
          trend={orders ? { value: 8.2, isPositive: true } : undefined}
          onClick={() => navigate("/admin/orders")}
        />
        
        <DashboardCard
          title="Produtos"
          value={isLoadingProducts ? "Carregando..." : products.length}
          description="Produtos cadastrados"
          icon={<Package className="h-4 w-4" />}
          onClick={() => navigate("/admin/products")}
        />
        
        <DashboardCard
          title="Usuários"
          value={isLoadingUsers ? "Carregando..." : users.length}
          description="Usuários cadastrados"
          icon={<Users className="h-4 w-4" />}
          trend={users ? { value: 5.3, isPositive: true } : undefined}
          onClick={() => navigate("/admin/users")}
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Revenue Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-primary" />
              Vendas e Receita (Últimos 7 dias)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingOrders ? (
              <Skeleton className="h-80 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={salesData} margin={{ top: 10, right: 30, left: 0, bottom: 30 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" orientation="left" stroke="#3B82F6" />
                  <YAxis yAxisId="right" orientation="right" stroke="#10B981" />
                  <Tooltip />
                  <Legend />
                  <Bar yAxisId="left" dataKey="vendas" name="Pedidos" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  <Bar yAxisId="right" dataKey="receita" name="Receita (R$)" fill="#10B981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Distribution Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Categories Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center">
                <Package className="h-4 w-4 mr-2 text-primary" />
                Produtos por Categoria
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingProducts ? (
                <Skeleton className="h-[150px] w-full" />
              ) : (
                <ResponsiveContainer width="100%" height={150}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={60}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Order Status Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center">
                <Activity className="h-4 w-4 mr-2 text-primary" />
                Status dos Pedidos
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingOrders ? (
                <Skeleton className="h-[150px] w-full" />
              ) : (
                <ResponsiveContainer width="100%" height={150}>
                  <PieChart>
                    <Pie
                      data={orderStatusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={60}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {orderStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="h-5 w-5 mr-2 text-primary" />
            Atividade Recente
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingOrders ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, index) => (
                <Skeleton key={index} className="h-12 w-full" />
              ))}
            </div>
          ) : orders && orders.length > 0 ? (
            <div className="space-y-4">
              {orders.slice(0, 5).map((order: any) => (
                <div key={order.id} className="flex items-center justify-between pb-4 border-b last:border-0">
                  <div>
                    <p className="font-medium">Pedido #{order.id}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(order.createdAt).toLocaleDateString('pt-BR')} - R${Number(order.totalAmount).toFixed(2).replace('.', ',')}
                    </p>
                  </div>
                  <div>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      order.status === 'delivered' 
                        ? 'bg-green-100 text-green-800' 
                        : order.status === 'shipped' 
                        ? 'bg-blue-100 text-blue-800'
                        : order.status === 'cancelled'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {order.status === 'pending' 
                        ? 'Pendente' 
                        : order.status === 'processing' 
                        ? 'Processando'
                        : order.status === 'shipped'
                        ? 'Enviado'
                        : order.status === 'delivered'
                        ? 'Entregue'
                        : 'Cancelado'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-6">Nenhum pedido recente encontrado</p>
          )}
        </CardContent>
      </Card>
    </AdminLayout>
  );
}
