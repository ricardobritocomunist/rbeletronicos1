import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { ShoppingCart, Package, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import CartItem from "@/components/ui/cart-item";
import { Separator } from "@/components/ui/separator";
import { formatCurrency } from "@/lib/utils";
import ProductSection from "@/components/ProductSection";

const Cart = () => {
  const { cartItems, isLoading, clearCart } = useCart();
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // If not authenticated, redirect to login
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      navigate("/login?redirect=/cart");
    }
  }, [isAuthenticated, isLoading, navigate]);

  // Calculate totals
  const subtotal = cartItems.reduce(
    (total, item) => total + item.product.price * item.cartItem.quantity,
    0
  );
  
  // Free shipping for orders over R$199
  const shippingCost = subtotal > 199 ? 0 : 15.9;
  
  // Total cost
  const total = subtotal + shippingCost;

  return (
    <>
      <Helmet>
        <title>Carrinho de Compras | TechDrop</title>
        <meta
          name="description"
          content="Revise seus itens e complete sua compra na TechDrop. Frete grátis em compras acima de R$199."
        />
      </Helmet>

      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-10">
        <div className="p-6">
          <h1 className="text-2xl font-bold mb-6 flex items-center">
            <ShoppingCart className="mr-2 h-6 w-6" /> Meu Carrinho
          </h1>

          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : cartItems.length === 0 ? (
            <div className="text-center py-10">
              <div className="bg-gray-100 inline-flex rounded-full p-6 mb-4">
                <Package className="h-10 w-10 text-gray-400" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Seu carrinho está vazio</h2>
              <p className="text-gray-600 mb-6">
                Parece que você ainda não adicionou nenhum produto ao seu carrinho.
              </p>
              <Link href="/products">
                <Button className="bg-primary hover:bg-primary/90 text-white px-6 py-2">
                  Continuar Comprando
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <CartItem key={item.cartItem.id} item={item} />
                  ))}
                </div>
                
                <div className="mt-6 flex justify-between">
                  <Button 
                    variant="outline" 
                    className="text-gray-600"
                    onClick={() => navigate("/products")}
                  >
                    Continuar Comprando
                  </Button>
                  <Button 
                    variant="outline" 
                    className="text-destructive hover:text-destructive-foreground hover:bg-destructive"
                    onClick={() => clearCart()}
                  >
                    Limpar Carrinho
                  </Button>
                </div>
              </div>

              {/* Order Summary */}
              <div className="bg-gray-50 p-6 rounded-lg h-fit">
                <h2 className="text-lg font-semibold mb-4">Resumo do Pedido</h2>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span>{formatCurrency(subtotal)}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">Frete</span>
                    <span>
                      {shippingCost === 0 ? (
                        <span className="text-green-600 font-medium">Grátis</span>
                      ) : (
                        formatCurrency(shippingCost)
                      )}
                    </span>
                  </div>
                  
                  {subtotal < 199 && (
                    <div className="text-sm text-gray-500 bg-blue-50 p-2 rounded border border-blue-100">
                      Adicione mais {formatCurrency(199 - subtotal)} para ganhar frete grátis!
                    </div>
                  )}
                  
                  <Separator />
                  
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>{formatCurrency(total)}</span>
                  </div>
                  
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 mt-4" 
                    size="lg"
                    onClick={() => navigate("/checkout")}
                  >
                    Finalizar Compra <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  
                  <div className="mt-4 text-xs text-gray-500">
                    <p>Ao finalizar sua compra, você concorda com nossos Termos de Serviço e Política de Privacidade.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Suggested Products */}
      <ProductSection
        title="Você pode gostar também"
        endpoint="/api/products?featured=true&limit=4"
        viewAllLink="/products?featured=true"
      />
    </>
  );
};

export default Cart;
