import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/context/AuthContext";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { productSchema } from "@/lib/validators";
import { z } from "zod";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Users, 
  PlusCircle,
  Search,
  Edit,
  Trash2,
  ArrowLeft,
  Save,
  X,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { generateSlug, formatCurrency } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

type ProductFormData = z.infer<typeof productSchema>;

const AdminSidebar = ({ currentPath }: { currentPath: string }) => {
  const [, navigate] = useLocation();
  const { logout } = useAuth();

  const navItems = [
    { path: "/admin", label: "Dashboard", icon: <LayoutDashboard className="mr-2 h-5 w-5" /> },
    { path: "/admin/products", label: "Produtos", icon: <Package className="mr-2 h-5 w-5" /> },
    { path: "/admin/orders", label: "Pedidos", icon: <ShoppingCart className="mr-2 h-5 w-5" /> },
  ];

  return (
    <div className="w-64 bg-neutral-dark text-white h-screen sticky top-0 p-6">
      <div className="mb-8">
        <h1 className="text-xl font-bold flex items-center">
          <LayoutDashboard className="mr-2 h-6 w-6" />
          TechDrop Admin
        </h1>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => (
          <Button
            key={item.path}
            variant={currentPath === item.path ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentPath === item.path ? "bg-gray-700" : "hover:bg-gray-700"
            } text-white`}
            onClick={() => navigate(item.path)}
          >
            {item.icon}
            {item.label}
          </Button>
        ))}
      </nav>

      <div className="mt-auto pt-8 border-t border-gray-700 mt-8">
        <Button 
          variant="ghost" 
          className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-700"
          onClick={() => navigate("/")}
        >
          <Users className="mr-2 h-5 w-5" />
          Ver Loja
        </Button>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-700"
          onClick={logout}
        >
          Sair
        </Button>
      </div>
    </div>
  );
};

const ProductManagement = () => {
  const [location, navigate] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [editingProduct, setEditingProduct] = useState(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState(null);
  const { toast } = useToast();
  
  // Get query params
  const params = new URLSearchParams(location.split("?")[1]);
  const action = params.get("action");
  
  // Initialize form for adding/editing product
  const form = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      slug: "",
      description: "",
      price: 0,
      image: "",
      categoryId: undefined,
      inStock: true,
      isFeatured: false,
      isNew: false,
    },
  });
  
  // Set up form watch for name to generate slug
  const watchName = form.watch("name");
  
  // Generate slug when name changes
  useEffect(() => {
    if (watchName && !editingProduct) {
      const slug = generateSlug(watchName);
      form.setValue("slug", slug);
    }
  }, [watchName, form, editingProduct]);
  
  // Check action param to show add product form
  useEffect(() => {
    if (action === "new") {
      setIsAddingProduct(true);
    }
  }, [action]);
  
  // Fetch products
  const { data: products, isLoading: isProductsLoading } = useQuery({
    queryKey: ["/api/products"],
    enabled: isAuthenticated && !!user?.isAdmin,
  });
  
  // Fetch categories for dropdown
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
    enabled: isAuthenticated && !!user?.isAdmin,
  });
  
  // Create product mutation
  const createProduct = useMutation({
    mutationFn: async (data: ProductFormData) => {
      const response = await apiRequest("POST", "/api/products", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Produto criado",
        description: "O produto foi criado com sucesso.",
      });
      setIsAddingProduct(false);
      form.reset();
      // Remove query param
      navigate("/admin/products");
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar produto",
        description: error.message || "Ocorreu um erro ao criar o produto.",
        variant: "destructive",
      });
    },
  });
  
  // Update product mutation
  const updateProduct = useMutation({
    mutationFn: async (data: ProductFormData & { id: number }) => {
      const { id, ...productData } = data;
      const response = await apiRequest("PUT", `/api/products/${id}`, productData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Produto atualizado",
        description: "O produto foi atualizado com sucesso.",
      });
      setEditingProduct(null);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar produto",
        description: error.message || "Ocorreu um erro ao atualizar o produto.",
        variant: "destructive",
      });
    },
  });
  
  // Delete product mutation
  const deleteProduct = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/products/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Produto excluído",
        description: "O produto foi excluído com sucesso.",
      });
      setIsDeleteDialogOpen(false);
      setProductToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Erro ao excluir produto",
        description: error.message || "Ocorreu um erro ao excluir o produto.",
        variant: "destructive",
      });
    },
  });
  
  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || !user?.isAdmin)) {
      navigate("/login?redirect=/admin/products");
    }
  }, [isAuthenticated, isLoading, user, navigate]);
  
  // Handle editing a product
  const handleEdit = (product) => {
    setEditingProduct(product);
    form.reset({
      name: product.name,
      slug: product.slug,
      description: product.description,
      price: product.price,
      compareAtPrice: product.compareAtPrice,
      image: product.image,
      categoryId: product.categoryId,
      inStock: product.inStock,
      isFeatured: product.isFeatured,
      isNew: product.isNew,
      specs: product.specs,
    });
  };
  
  // Handle submitting the form
  const onSubmit = (data: ProductFormData) => {
    if (editingProduct) {
      updateProduct.mutate({ id: editingProduct.id, ...data });
    } else {
      createProduct.mutate(data);
    }
  };
  
  // Handle canceling add/edit
  const handleCancel = () => {
    setEditingProduct(null);
    setIsAddingProduct(false);
    form.reset();
    // Remove query param if adding
    if (isAddingProduct) {
      navigate("/admin/products");
    }
  };
  
  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    if (productToDelete) {
      deleteProduct.mutate(productToDelete.id);
    }
  };
  
  // Filter products by search term
  const filteredProducts = products?.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Show loading while checking auth state
  if (isLoading || !user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Gerenciamento de Produtos | TechDrop</title>
        <meta
          name="description"
          content="Gerenciamento de produtos da TechDrop. Adicione, edite e remova produtos da loja."
        />
      </Helmet>
      
      <div className="flex h-screen bg-gray-100">
        <AdminSidebar currentPath={location} />
        
        <main className="flex-1 p-6 overflow-y-auto">
          {isAddingProduct || editingProduct ? (
            <div className="space-y-6">
              <div className="flex items-center">
                <Button
                  variant="ghost"
                  className="mr-4"
                  onClick={handleCancel}
                >
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Voltar
                </Button>
                <h1 className="text-3xl font-bold">
                  {editingProduct ? "Editar Produto" : "Adicionar Produto"}
                </h1>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>{editingProduct ? "Editar Produto" : "Novo Produto"}</CardTitle>
                  <CardDescription>
                    {editingProduct
                      ? "Edite as informações do produto existente."
                      : "Preencha os campos para adicionar um novo produto."}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nome do Produto</FormLabel>
                              <FormControl>
                                <Input placeholder="Nome do produto" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="slug"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Slug</FormLabel>
                              <FormControl>
                                <Input placeholder="slug-do-produto" {...field} />
                              </FormControl>
                              <FormDescription>
                                Usado na URL do produto. Deixe em branco para gerar automaticamente.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Descrição</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Descrição detalhada do produto"
                                className="min-h-[120px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="price"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preço (R$)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01"
                                  placeholder="0.00" 
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="compareAtPrice"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preço Comparativo (R$)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01"
                                  placeholder="0.00" 
                                  {...field}
                                  value={field.value || ""}
                                  onChange={(e) => {
                                    const value = e.target.value === "" ? undefined : parseFloat(e.target.value);
                                    field.onChange(value);
                                  }}
                                />
                              </FormControl>
                              <FormDescription>
                                Preço anterior ou sugerido (opcional)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="image"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>URL da Imagem Principal</FormLabel>
                              <FormControl>
                                <Input placeholder="https://exemplo.com/imagem.jpg" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="categoryId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Categoria</FormLabel>
                              <Select
                                onValueChange={(value) => field.onChange(parseInt(value))}
                                value={field.value?.toString()}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Selecione uma categoria" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {categories?.map((category) => (
                                    <SelectItem key={category.id} value={category.id.toString()}>
                                      {category.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <FormField
                          control={form.control}
                          name="inStock"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Em Estoque</FormLabel>
                                <FormDescription>
                                  Produto disponível para compra
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="isFeatured"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Em Destaque</FormLabel>
                                <FormDescription>
                                  Mostrar na seção de destaque
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="isNew"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Novo Produto</FormLabel>
                                <FormDescription>
                                  Mostrar na seção de novidades
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="flex justify-end gap-4">
                        <Button variant="outline" type="button" onClick={handleCancel}>
                          Cancelar
                        </Button>
                        <Button 
                          type="submit"
                          className="bg-primary hover:bg-primary/90"
                          disabled={createProduct.isPending || updateProduct.isPending}
                        >
                          {createProduct.isPending || updateProduct.isPending ? (
                            <span className="flex items-center">
                              <span className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
                              {editingProduct ? "Atualizando..." : "Salvando..."}
                            </span>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              {editingProduct ? "Atualizar Produto" : "Salvar Produto"}
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold">Gerenciamento de Produtos</h1>
                <Button 
                  className="bg-primary hover:bg-primary/90"
                  onClick={() => setIsAddingProduct(true)}
                >
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Adicionar Produto
                </Button>
              </div>
              
              <Card>
                <CardHeader>
                  <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                    <CardTitle>Lista de Produtos</CardTitle>
                    <div className="relative w-full md:w-80">
                      <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                      <Input
                        placeholder="Buscar produtos..."
                        className="pl-8"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {isProductsLoading ? (
                    <div className="flex justify-center py-8">
                      <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                    </div>
                  ) : filteredProducts?.length === 0 ? (
                    <div className="text-center py-8">
                      <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium mb-2">Nenhum produto encontrado</h3>
                      <p className="text-gray-500">
                        Não foram encontrados produtos com os critérios de busca.
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Imagem</TableHead>
                            <TableHead>Nome</TableHead>
                            <TableHead>Categoria</TableHead>
                            <TableHead>Preço</TableHead>
                            <TableHead>Estoque</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredProducts?.map((product) => {
                            const category = categories?.find(c => c.id === product.categoryId);
                            return (
                              <TableRow key={product.id}>
                                <TableCell>
                                  <img 
                                    src={product.image} 
                                    alt={product.name}
                                    className="h-10 w-10 object-cover rounded"
                                  />
                                </TableCell>
                                <TableCell className="font-medium">{product.name}</TableCell>
                                <TableCell>{category?.name || "-"}</TableCell>
                                <TableCell>{formatCurrency(product.price)}</TableCell>
                                <TableCell>
                                  {product.inStock ? (
                                    <Badge className="bg-green-500">Em estoque</Badge>
                                  ) : (
                                    <Badge variant="outline">Indisponível</Badge>
                                  )}
                                </TableCell>
                                <TableCell>
                                  {product.isFeatured && (
                                    <Badge className="bg-primary mr-1">Destaque</Badge>
                                  )}
                                  {product.isNew && (
                                    <Badge className="bg-accent">Novo</Badge>
                                  )}
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleEdit(product)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="text-destructive"
                                    onClick={() => {
                                      setProductToDelete(product);
                                      setIsDeleteDialogOpen(true);
                                    }}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
          
          {/* Delete Confirmation Dialog */}
          <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Confirmar exclusão</DialogTitle>
                <DialogDescription>
                  Tem certeza que deseja excluir o produto "{productToDelete?.name}"? Esta ação não pode ser desfeita.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setIsDeleteDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleDeleteConfirm}
                  disabled={deleteProduct.isPending}
                >
                  {deleteProduct.isPending ? (
                    <span className="flex items-center">
                      <span className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
                      Excluindo...
                    </span>
                  ) : (
                    "Excluir Produto"
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </>
  );
};

export default ProductManagement;
