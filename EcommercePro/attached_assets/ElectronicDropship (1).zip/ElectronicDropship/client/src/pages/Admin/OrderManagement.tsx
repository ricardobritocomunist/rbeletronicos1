import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/context/AuthContext";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Users, 
  Search,
  ChevronDown,
  CreditCard,
  Truck,
  MapPin,
  CheckCircle,
  User,
  Calendar,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate } from "@/lib/utils";

// Order status badge color mapping
const statusColors = {
  pending: "bg-yellow-500",
  processing: "bg-blue-500",
  shipped: "bg-purple-500",
  delivered: "bg-green-500",
  cancelled: "bg-red-500",
};

// Order status human-readable labels
const statusLabels = {
  pending: "Pendente",
  processing: "Processando",
  shipped: "Enviado",
  delivered: "Entregue",
  cancelled: "Cancelado",
};

const AdminSidebar = ({ currentPath }: { currentPath: string }) => {
  const [, navigate] = useLocation();
  const { logout } = useAuth();

  const navItems = [
    { path: "/admin", label: "Dashboard", icon: <LayoutDashboard className="mr-2 h-5 w-5" /> },
    { path: "/admin/products", label: "Produtos", icon: <Package className="mr-2 h-5 w-5" /> },
    { path: "/admin/orders", label: "Pedidos", icon: <ShoppingCart className="mr-2 h-5 w-5" /> },
  ];

  return (
    <div className="w-64 bg-neutral-dark text-white h-screen sticky top-0 p-6">
      <div className="mb-8">
        <h1 className="text-xl font-bold flex items-center">
          <LayoutDashboard className="mr-2 h-6 w-6" />
          TechDrop Admin
        </h1>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => (
          <Button
            key={item.path}
            variant={currentPath === item.path ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentPath === item.path ? "bg-gray-700" : "hover:bg-gray-700"
            } text-white`}
            onClick={() => navigate(item.path)}
          >
            {item.icon}
            {item.label}
          </Button>
        ))}
      </nav>

      <div className="mt-auto pt-8 border-t border-gray-700 mt-8">
        <Button 
          variant="ghost" 
          className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-700"
          onClick={() => navigate("/")}
        >
          <Users className="mr-2 h-5 w-5" />
          Ver Loja
        </Button>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-700"
          onClick={logout}
        >
          Sair
        </Button>
      </div>
    </div>
  );
};

const OrderManagement = () => {
  const [location, navigate] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isOrderDetailOpen, setIsOrderDetailOpen] = useState(false);
  const { toast } = useToast();
  
  // Fetch orders
  const { data: orders, isLoading: isOrdersLoading } = useQuery({
    queryKey: ["/api/admin/orders"],
    enabled: isAuthenticated && !!user?.isAdmin,
  });
  
  // Fetch order details when an order is selected
  const { data: orderDetails, isLoading: isOrderDetailsLoading } = useQuery({
    queryKey: [selectedOrder ? `/api/orders/${selectedOrder.id}` : null],
    enabled: !!selectedOrder,
  });
  
  // Update order status mutation
  const updateOrderStatus = useMutation({
    mutationFn: async ({ id, status }) => {
      const response = await apiRequest("PUT", `/api/admin/orders/${id}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      if (selectedOrder) {
        queryClient.invalidateQueries({ queryKey: [`/api/orders/${selectedOrder.id}`] });
      }
      toast({
        title: "Status atualizado",
        description: "O status do pedido foi atualizado com sucesso.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar status",
        description: error.message || "Ocorreu um erro ao atualizar o status do pedido.",
        variant: "destructive",
      });
    },
  });
  
  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || !user?.isAdmin)) {
      navigate("/login?redirect=/admin/orders");
    }
  }, [isAuthenticated, isLoading, user, navigate]);
  
  // Handle order status change
  const handleStatusChange = (orderId, newStatus) => {
    updateOrderStatus.mutate({ id: orderId, status: newStatus });
  };
  
  // Filter orders by search term and status
  const filteredOrders = orders?.filter(
    (order) => {
      // Status filter
      if (statusFilter !== "all" && order.status !== statusFilter) {
        return false;
      }
      
      // Search term filter (by order ID)
      if (searchTerm && !order.id.toString().includes(searchTerm)) {
        return false;
      }
      
      return true;
    }
  );
  
  // Show loading while checking auth state
  if (isLoading || !user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Gerenciamento de Pedidos | TechDrop</title>
        <meta
          name="description"
          content="Gerenciamento de pedidos da TechDrop. Visualize e atualize o status dos pedidos."
        />
      </Helmet>
      
      <div className="flex h-screen bg-gray-100">
        <AdminSidebar currentPath={location} />
        
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h1 className="text-3xl font-bold">Gerenciamento de Pedidos</h1>
            </div>
            
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                  <CardTitle>Lista de Pedidos</CardTitle>
                  <div className="flex flex-col md:flex-row gap-2">
                    <div className="relative w-full md:w-60">
                      <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                      <Input
                        placeholder="Buscar por ID..."
                        className="pl-8"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-full md:w-40">
                        <SelectValue placeholder="Filtrar por status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos</SelectItem>
                        <SelectItem value="pending">Pendente</SelectItem>
                        <SelectItem value="processing">Processando</SelectItem>
                        <SelectItem value="shipped">Enviado</SelectItem>
                        <SelectItem value="delivered">Entregue</SelectItem>
                        <SelectItem value="cancelled">Cancelado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isOrdersLoading ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                  </div>
                ) : filteredOrders?.length === 0 ? (
                  <div className="text-center py-8">
                    <ShoppingCart className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium mb-2">Nenhum pedido encontrado</h3>
                    <p className="text-gray-500">
                      Não foram encontrados pedidos com os critérios de filtro.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Data</TableHead>
                          <TableHead>Total</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Pagamento</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredOrders?.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">#{order.id}</TableCell>
                            <TableCell>{formatDate(order.createdAt)}</TableCell>
                            <TableCell>{formatCurrency(order.total)}</TableCell>
                            <TableCell>
                              <Badge className={`${statusColors[order.status] || "bg-gray-500"}`}>
                                {statusLabels[order.status] || order.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="flex items-center w-fit">
                                <CreditCard className="mr-1 h-3 w-3" />
                                {order.paymentMethod}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setSelectedOrder(order);
                                  setIsOrderDetailOpen(true);
                                }}
                              >
                                Detalhes
                              </Button>
                              <Select 
                                defaultValue={order.status} 
                                onValueChange={(value) => handleStatusChange(order.id, value)}
                              >
                                <SelectTrigger className="w-[130px] ml-2 h-8">
                                  <SelectValue placeholder="Atualizar status" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="pending">Pendente</SelectItem>
                                  <SelectItem value="processing">Processando</SelectItem>
                                  <SelectItem value="shipped">Enviado</SelectItem>
                                  <SelectItem value="delivered">Entregue</SelectItem>
                                  <SelectItem value="cancelled">Cancelado</SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Order Detail Dialog */}
          <Dialog open={isOrderDetailOpen} onOpenChange={setIsOrderDetailOpen}>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Detalhes do Pedido #{selectedOrder?.id}</DialogTitle>
                <DialogDescription>
                  Informações completas sobre o pedido.
                </DialogDescription>
              </DialogHeader>
              
              {isOrderDetailsLoading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : orderDetails ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2 text-primary" />
                          <CardTitle className="text-sm">Informações do Pedido</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="text-sm">
                        <div className="space-y-1">
                          <p><span className="font-medium">Data:</span> {formatDate(orderDetails.order.createdAt)}</p>
                          <p>
                            <span className="font-medium">Status:</span>
                            <Badge className={`${statusColors[orderDetails.order.status] || "bg-gray-500"} ml-2`}>
                              {statusLabels[orderDetails.order.status] || orderDetails.order.status}
                            </Badge>
                          </p>
                          <p><span className="font-medium">Total:</span> {formatCurrency(orderDetails.order.total)}</p>
                          <p>
                            <span className="font-medium">Pagamento:</span>
                            <Badge variant="outline" className="flex items-center w-fit ml-2">
                              <CreditCard className="mr-1 h-3 w-3" />
                              {orderDetails.order.paymentMethod}
                            </Badge>
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <div className="flex items-center">
                          <User className="h-4 w-4 mr-2 text-primary" />
                          <CardTitle className="text-sm">Cliente</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="text-sm">
                        <div className="space-y-1">
                          <p><span className="font-medium">ID do Cliente:</span> #{orderDetails.order.userId}</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-2 text-primary" />
                          <CardTitle className="text-sm">Endereço de Entrega</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="text-sm">
                        <div className="space-y-1">
                          <p>{orderDetails.order.shippingAddress.name}</p>
                          <p>{orderDetails.order.shippingAddress.address}</p>
                          <p>
                            {orderDetails.order.shippingAddress.city}, {orderDetails.order.shippingAddress.state}{" "}
                            {orderDetails.order.shippingAddress.postalCode}
                          </p>
                          <p>{orderDetails.order.shippingAddress.country}</p>
                          <p>{orderDetails.order.shippingAddress.phone}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Itens do Pedido</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Produto</TableHead>
                            <TableHead>Preço</TableHead>
                            <TableHead>Quantidade</TableHead>
                            <TableHead className="text-right">Subtotal</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {orderDetails.items.map((item) => (
                            <TableRow key={item.id}>
                              <TableCell>
                                <div className="flex items-center space-x-3">
                                  <img
                                    src={item.image}
                                    alt={item.name}
                                    className="h-10 w-10 rounded-md object-cover"
                                  />
                                  <div>
                                    <p className="font-medium">{item.name}</p>
                                    <p className="text-xs text-gray-500">ID: {item.productId}</p>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>{formatCurrency(item.price)}</TableCell>
                              <TableCell>{item.quantity}</TableCell>
                              <TableCell className="text-right">
                                {formatCurrency(item.price * item.quantity)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                    <CardFooter className="flex justify-end">
                      <div className="text-right space-y-1">
                        <p className="text-sm"><span className="font-medium">Subtotal:</span> {formatCurrency(orderDetails.order.total)}</p>
                        <p className="text-sm"><span className="font-medium">Frete:</span> Grátis</p>
                        <p className="text-lg font-bold">{formatCurrency(orderDetails.order.total)}</p>
                      </div>
                    </CardFooter>
                  </Card>
                  
                  <div className="flex justify-between">
                    <Button variant="outline" onClick={() => setIsOrderDetailOpen(false)}>
                      Fechar
                    </Button>
                    <div className="flex space-x-2">
                      <Select 
                        value={orderDetails.order.status} 
                        onValueChange={(value) => {
                          handleStatusChange(orderDetails.order.id, value);
                        }}
                      >
                        <SelectTrigger className="w-[200px]">
                          <SelectValue placeholder="Atualizar status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pendente</SelectItem>
                          <SelectItem value="processing">Processando</SelectItem>
                          <SelectItem value="shipped">Enviado</SelectItem>
                          <SelectItem value="delivered">Entregue</SelectItem>
                          <SelectItem value="cancelled">Cancelado</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button 
                        className="bg-primary hover:bg-primary/90"
                        onClick={() => {
                          const newStatus = updateOrderStatus.isPending ? orderDetails.order.status : orderDetails.order.status;
                          handleStatusChange(orderDetails.order.id, newStatus);
                        }}
                        disabled={updateOrderStatus.isPending}
                      >
                        {updateOrderStatus.isPending ? (
                          <span className="flex items-center">
                            <span className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
                            Atualizando...
                          </span>
                        ) : (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4" />
                            Atualizar Status
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">Não foi possível carregar os detalhes do pedido.</p>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </>
  );
};

export default OrderManagement;
