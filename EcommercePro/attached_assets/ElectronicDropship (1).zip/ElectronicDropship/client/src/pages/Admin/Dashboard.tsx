import { useEffect } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Users, 
  DollarSign,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { formatCurrency } from "@/lib/utils";

// Sample data for charts - in a real app this would come from API
const revenueData = [
  { name: "Jan", total: 1800 },
  { name: "Fev", total: 2200 },
  { name: "Mar", total: 2600 },
  { name: "Abr", total: 2400 },
  { name: "Mai", total: 2800 },
  { name: "Jun", total: 3200 },
  { name: "Jul", total: 3600 },
];

const AdminSidebar = ({ currentPath }: { currentPath: string }) => {
  const [, navigate] = useLocation();
  const { logout } = useAuth();

  const navItems = [
    { path: "/admin", label: "Dashboard", icon: <LayoutDashboard className="mr-2 h-5 w-5" /> },
    { path: "/admin/products", label: "Produtos", icon: <Package className="mr-2 h-5 w-5" /> },
    { path: "/admin/orders", label: "Pedidos", icon: <ShoppingCart className="mr-2 h-5 w-5" /> },
  ];

  return (
    <div className="w-64 bg-neutral-dark text-white h-screen sticky top-0 p-6">
      <div className="mb-8">
        <h1 className="text-xl font-bold flex items-center">
          <LayoutDashboard className="mr-2 h-6 w-6" />
          TechDrop Admin
        </h1>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => (
          <Button
            key={item.path}
            variant={currentPath === item.path ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              currentPath === item.path ? "bg-gray-700" : "hover:bg-gray-700"
            } text-white`}
            onClick={() => navigate(item.path)}
          >
            {item.icon}
            {item.label}
          </Button>
        ))}
      </nav>

      <div className="mt-auto pt-8 border-t border-gray-700 mt-8">
        <Button 
          variant="ghost" 
          className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-700"
          onClick={() => navigate("/")}
        >
          <Users className="mr-2 h-5 w-5" />
          Ver Loja
        </Button>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-700"
          onClick={logout}
        >
          Sair
        </Button>
      </div>
    </div>
  );
};

const DashboardCard = ({ title, value, description, icon, trend = "neutral", percentage = null }) => {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {percentage && (
          <p className={`text-xs flex items-center ${trend === "up" ? "text-green-500" : trend === "down" ? "text-red-500" : "text-gray-500"}`}>
            {trend === "up" ? (
              <ArrowUpRight className="mr-1 h-4 w-4" />
            ) : trend === "down" ? (
              <ArrowDownRight className="mr-1 h-4 w-4" />
            ) : null}
            {percentage}% em relação ao mês anterior
          </p>
        )}
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
};

const Dashboard = () => {
  const [location, navigate] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  
  // Fetch summary data
  const { data: productsData } = useQuery({
    queryKey: ["/api/products"],
    enabled: isAuthenticated && !!user?.isAdmin,
  });
  
  const { data: ordersData } = useQuery({
    queryKey: ["/api/admin/orders"],
    enabled: isAuthenticated && !!user?.isAdmin,
  });
  
  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || !user?.isAdmin)) {
      navigate("/login?redirect=/admin");
    }
  }, [isAuthenticated, isLoading, user, navigate]);
  
  if (isLoading || !user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  // Count totals
  const productCount = productsData?.length || 0;
  const orderCount = ordersData?.length || 0;
  const revenue = ordersData?.reduce((total, order) => total + order.total, 0) || 0;
  const pendingOrders = ordersData?.filter(order => order.status === "pending").length || 0;

  return (
    <>
      <Helmet>
        <title>Painel de Administração | TechDrop</title>
        <meta
          name="description"
          content="Painel administrativo da TechDrop para gerenciamento de produtos e pedidos."
        />
      </Helmet>
      
      <div className="flex h-screen bg-gray-100">
        <AdminSidebar currentPath={location} />
        
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h1 className="text-3xl font-bold">Dashboard</h1>
              <p className="text-gray-600">Bem-vindo(a), {user.name}</p>
            </div>
            
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <DashboardCard 
                title="Receita Total" 
                value={formatCurrency(revenue)}
                description="Receita total de vendas"
                icon={<DollarSign className="h-4 w-4 text-gray-500" />}
                trend="up"
                percentage="12.5"
              />
              <DashboardCard 
                title="Pedidos" 
                value={orderCount}
                description="Total de pedidos"
                icon={<ShoppingCart className="h-4 w-4 text-gray-500" />}
                trend="up"
                percentage="8.2"
              />
              <DashboardCard 
                title="Produtos" 
                value={productCount}
                description="Total de produtos cadastrados"
                icon={<Package className="h-4 w-4 text-gray-500" />}
              />
              <DashboardCard 
                title="Pedidos Pendentes" 
                value={pendingOrders}
                description="Pedidos aguardando processamento"
                icon={<ShoppingCart className="h-4 w-4 text-gray-500" />}
                trend="down"
                percentage="5.4"
              />
            </div>
            
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList>
                <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                <TabsTrigger value="analytics">Análise</TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Receita Mensal</CardTitle>
                    <CardDescription>
                      Visualização do desempenho de vendas por mês.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                      <BarChart data={revenueData}>
                        <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `R$${value}`} />
                        <Tooltip 
                          formatter={(value) => [`R$${value}`, "Receita"]}
                          contentStyle={{ background: "white", border: "1px solid #e2e8f0" }}
                        />
                        <CartesianGrid vertical={false} stroke="#e2e8f0" />
                        <Bar dataKey="total" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Pedidos Recentes</CardTitle>
                      <CardDescription>
                        Últimos pedidos realizados.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {ordersData && ordersData.length > 0 ? (
                        <div className="space-y-4">
                          {ordersData.slice(0, 5).map((order) => (
                            <div key={order.id} className="flex items-center justify-between">
                              <div>
                                <p className="font-medium">Pedido #{order.id}</p>
                                <p className="text-sm text-gray-500">Status: {order.status}</p>
                              </div>
                              <div className="text-right">
                                <p className="font-medium">{formatCurrency(order.total)}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-center py-4">Nenhum pedido encontrado.</p>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button variant="outline" className="w-full" onClick={() => navigate("/admin/orders")}>
                        Ver todos
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Produtos em Destaque</CardTitle>
                      <CardDescription>
                        Produtos mais vendidos.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {productsData && productsData.length > 0 ? (
                        <div className="space-y-4">
                          {productsData
                            .filter(product => product.isFeatured)
                            .slice(0, 5)
                            .map((product) => (
                              <div key={product.id} className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">{product.name}</p>
                                  <p className="text-sm text-gray-500">Estoque: {product.inStock ? "Disponível" : "Indisponível"}</p>
                                </div>
                                <div className="text-right">
                                  <p className="font-medium">{formatCurrency(product.price)}</p>
                                </div>
                              </div>
                            ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-center py-4">Nenhum produto em destaque.</p>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button variant="outline" className="w-full" onClick={() => navigate("/admin/products")}>
                        Ver todos
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Ações Rápidas</CardTitle>
                      <CardDescription>
                        Atalhos para tarefas comuns.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/admin/products?action=new")}>
                        <Package className="mr-2 h-4 w-4" />
                        Adicionar Produto
                      </Button>
                      <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/admin/orders")}>
                        <ShoppingCart className="mr-2 h-4 w-4" />
                        Gerenciar Pedidos
                      </Button>
                      <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/")}>
                        <BarChart3 className="mr-2 h-4 w-4" />
                        Ver Loja
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="analytics" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Análise de Vendas</CardTitle>
                    <CardDescription>
                      Análises detalhadas serão implementadas em breve.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex justify-center items-center py-8">
                    <div className="text-center">
                      <BarChart3 className="mx-auto h-16 w-16 text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium mb-2">Em Desenvolvimento</h3>
                      <p className="text-gray-500 max-w-md">
                        Esta funcionalidade está sendo implementada e estará disponível em breve.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </>
  );
};

export default Dashboard;
