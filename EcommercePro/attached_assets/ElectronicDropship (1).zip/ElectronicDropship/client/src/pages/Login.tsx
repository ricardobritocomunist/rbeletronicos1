import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/context/AuthContext";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { loginSchema } from "@/lib/validators";
import { BoltIcon, LogIn } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

type FormData = z.infer<typeof loginSchema>;

const Login = () => {
  const [location, navigate] = useLocation();
  const { login, isAuthenticated, isLoading } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get redirect URL from query params
  const params = new URLSearchParams(location.split("?")[1]);
  const redirectUrl = params.get("redirect") || "/";
  
  const form = useForm<FormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated && !isLoading) {
      navigate(redirectUrl);
    }
  }, [isAuthenticated, isLoading, navigate, redirectUrl]);
  
  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      const success = await login(data.username, data.password);
      if (success) {
        navigate(redirectUrl);
      }
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Show loading while checking auth state
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  // Don't show login form if already authenticated
  if (isAuthenticated) {
    return null;
  }
  
  return (
    <>
      <Helmet>
        <title>Login | TechDrop</title>
        <meta
          name="description"
          content="Faça login na sua conta TechDrop para acompanhar seus pedidos e acessar ofertas exclusivas."
        />
      </Helmet>
      
      <div className="flex justify-center py-8">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <div className="flex justify-center mb-4">
              <div className="flex items-center space-x-2">
                <BoltIcon className="text-primary h-8 w-8" />
                <span className="text-2xl font-bold text-neutral-dark">Tech<span className="text-primary">Drop</span></span>
              </div>
            </div>
            <CardTitle className="text-2xl text-center">Bem-vindo(a) de volta</CardTitle>
            <CardDescription className="text-center">
              Faça login na sua conta para continuar
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome de usuário</FormLabel>
                      <FormControl>
                        <Input placeholder="Digite seu nome de usuário" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Digite sua senha" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/90"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <span className="flex items-center">
                      <span className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
                      Entrando...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <LogIn className="mr-2 h-5 w-5" />
                      Entrar
                    </span>
                  )}
                </Button>
              </form>
            </Form>
            
            <div className="text-center">
              <Link href="/forgot-password" className="text-sm text-primary hover:underline">
                Esqueceu sua senha?
              </Link>
            </div>
            
            <Separator />
            
            <div className="text-center">
              <p className="text-sm text-gray-600">
                Não tem uma conta?{" "}
                <Link 
                  href={redirectUrl ? `/register?redirect=${encodeURIComponent(redirectUrl)}` : "/register"} 
                  className="text-primary hover:underline font-medium"
                >
                  Cadastre-se
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default Login;
