import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/context/AuthContext";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { updateProfileSchema } from "@/lib/validators";
import { User, Package, CreditCard, LogOut, ShoppingBag, Settings, Save, AlertCircle } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

type FormData = z.infer<typeof updateProfileSchema>;

const UserProfile = () => {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, isLoading, logout, updateProfile } = useAuth();
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(updateProfileSchema),
    defaultValues: {
      email: "",
      name: "",
      address: "",
      city: "",
      state: "",
      postalCode: "",
      country: "",
      phone: "",
    },
  });
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      navigate("/login?redirect=/profile");
    }
  }, [isAuthenticated, isLoading, navigate]);
  
  // Update form values when user data loads
  useEffect(() => {
    if (user) {
      form.reset({
        email: user.email || "",
        name: user.name || "",
        address: user.address || "",
        city: user.city || "",
        state: user.state || "",
        postalCode: user.postalCode || "",
        country: user.country || "",
        phone: user.phone || "",
      });
    }
  }, [user, form]);
  
  const onSubmit = async (data: FormData) => {
    setIsUpdating(true);
    try {
      const success = await updateProfile(data);
      if (success) {
        toast({
          title: "Perfil atualizado",
          description: "Suas informações foram atualizadas com sucesso.",
        });
      }
    } finally {
      setIsUpdating(false);
    }
  };
  
  const handleLogout = () => {
    logout();
  };
  
  // Show loading while checking auth state
  if (isLoading || !user) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Meu Perfil | TechDrop</title>
        <meta
          name="description"
          content="Gerencie seus dados pessoais e acompanhe seus pedidos na TechDrop."
        />
      </Helmet>
      
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-8">Meu Perfil</h1>
        
        <Tabs defaultValue="profile" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile" className="flex items-center">
              <User className="mr-2 h-4 w-4" /> Perfil
            </TabsTrigger>
            <TabsTrigger value="orders" className="flex items-center">
              <Package className="mr-2 h-4 w-4" /> Pedidos
            </TabsTrigger>
            <TabsTrigger value="addresses" className="flex items-center">
              <ShoppingBag className="mr-2 h-4 w-4" /> Endereços
            </TabsTrigger>
            <TabsTrigger value="payment" className="flex items-center">
              <CreditCard className="mr-2 h-4 w-4" /> Pagamento
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Informações Pessoais</CardTitle>
                <CardDescription>
                  Atualize suas informações pessoais. Seu email será usado para comunicações importantes sobre suas compras.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {user.isAdmin && (
                  <Alert className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Conta de Administrador</AlertTitle>
                    <AlertDescription>
                      Você está logado como administrador e tem acesso à área administrativa.
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="ml-4"
                        onClick={() => navigate("/admin")}
                      >
                        <Settings className="mr-2 h-4 w-4" /> Acessar Painel
                      </Button>
                    </AlertDescription>
                  </Alert>
                )}
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome completo</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Telefone</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Separator />
                    
                    <h3 className="font-medium text-lg">Endereço de Entrega</h3>
                    
                    <FormField
                      control={form.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Endereço</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cidade</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Estado</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="postalCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CEP</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>País</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex justify-between">
                      <Button
                        type="submit"
                        className="bg-primary hover:bg-primary/90"
                        disabled={isUpdating}
                      >
                        {isUpdating ? (
                          <span className="flex items-center">
                            <span className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
                            Salvando...
                          </span>
                        ) : (
                          <span className="flex items-center">
                            <Save className="mr-2 h-4 w-4" />
                            Salvar Alterações
                          </span>
                        )}
                      </Button>
                      
                      <Button
                        variant="outline"
                        className="text-destructive hover:text-destructive-foreground hover:bg-destructive"
                        onClick={handleLogout}
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        Sair
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>Meus Pedidos</CardTitle>
                <CardDescription>
                  Visualize e acompanhe o status dos seus pedidos.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  className="mb-4"
                  onClick={() => navigate("/orders")}
                >
                  <Package className="mr-2 h-4 w-4" />
                  Ver Histórico de Pedidos
                </Button>
                
                <p className="text-gray-500 text-center py-6">
                  Aqui você poderá ver seus pedidos mais recentes.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="addresses">
            <Card>
              <CardHeader>
                <CardTitle>Endereços de Entrega</CardTitle>
                <CardDescription>
                  Gerencie seus endereços de entrega.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500 text-center py-6">
                  Funcionalidade em breve disponível.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="payment">
            <Card>
              <CardHeader>
                <CardTitle>Métodos de Pagamento</CardTitle>
                <CardDescription>
                  Gerencie seus métodos de pagamento.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500 text-center py-6">
                  Funcionalidade em breve disponível.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default UserProfile;
