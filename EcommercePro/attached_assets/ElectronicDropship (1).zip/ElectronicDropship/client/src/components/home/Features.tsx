import { Truck, CreditCard, Shield, Headset } from "lucide-react";

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const Feature = ({ icon, title, description }: FeatureProps) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md flex items-center">
      <div className="bg-primary/10 rounded-full p-4 mr-4">
        {icon}
      </div>
      <div>
        <h3 className="font-semibold mb-1">{title}</h3>
        <p className="text-gray-600 text-sm">{description}</p>
      </div>
    </div>
  );
};

const Features = () => {
  return (
    <section className="mb-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Feature 
          icon={<Truck className="text-primary text-xl" />}
          title="Envio Rápido"
          description="Entrega em todo o Brasil"
        />
        
        <Feature 
          icon={<CreditCard className="text-primary text-xl" />}
          title="Pagamento Seguro"
          description="Múltiplas formas de pagamento"
        />
        
        <Feature 
          icon={<Shield className="text-primary text-xl" />}
          title="Garantia"
          description="12 meses em todos produtos"
        />
        
        <Feature 
          icon={<Headset className="text-primary text-xl" />}
          title="Suporte 24/7"
          description="Atendimento especializado"
        />
      </div>
    </section>
  );
};

export default Features;
