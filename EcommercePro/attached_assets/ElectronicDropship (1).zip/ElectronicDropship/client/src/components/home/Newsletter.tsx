import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const Newsletter = () => {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Error",
        description: "Por favor, insira seu e-mail",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    // In a real application, you would send this to an API
    setTimeout(() => {
      setIsLoading(false);
      setEmail("");
      toast({
        title: "Sucesso!",
        description: "Obrigado por se inscrever na nossa newsletter!",
      });
    }, 1000);
  };

  return (
    <section className="mb-12 bg-neutral-dark rounded-xl overflow-hidden">
      <div className="p-8 md:p-12">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-white text-2xl md:text-3xl font-bold mb-3">Inscreva-se e ganhe 10% de desconto</h2>
          <p className="text-white/80 mb-6">Receba nossas ofertas exclusivas e novidades diretamente no seu e-mail.</p>
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <Input
              type="email"
              placeholder="Seu e-mail"
              className="flex-1 px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Button
              type="submit"
              className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg font-medium"
              disabled={isLoading}
            >
              {isLoading ? "Enviando..." : "Quero receber ofertas"}
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
