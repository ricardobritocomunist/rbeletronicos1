import { useState } from "react";
import { Link } from "wouter";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

// Define the slide interface
interface Slide {
  id: number;
  imageUrl: string;
  title: string;
  description: string;
  ctaText: string;
  ctaLink: string;
}

// Define the slides data
const slides: Slide[] = [
  {
    id: 1,
    imageUrl: "https://images.unsplash.com/photo-1526738549149-8e07eca6c147",
    title: "Tecnologia de ponta, ao seu alcance",
    description: "Descubra os últimos gadgets e acessórios com os melhores preços do mercado.",
    ctaText: "Ver ofertas",
    ctaLink: "/category/all"
  },
  {
    id: 2,
    imageUrl: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0",
    title: "Tablets e acessórios",
    description: "Encontre o tablet perfeito para trabalho, estudo ou entretenimento.",
    ctaText: "Explorar tablets",
    ctaLink: "/category/tablets"
  },
  {
    id: 3,
    imageUrl: "https://images.unsplash.com/photo-1546868871-7041f2a55e12",
    title: "Smartwatches em promoção",
    description: "Até 30% de desconto em smartwatches e fitness trackers.",
    ctaText: "Comprar agora",
    ctaLink: "/category/wearables"
  }
];

const Hero = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <div className="relative rounded-xl overflow-hidden mb-10 shadow-lg">
      {/* Hero Image */}
      <div className="relative h-[400px] overflow-hidden">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-500 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
          >
            <img
              src={slide.imageUrl}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            
            {/* Hero Content */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex items-center">
              <div className="px-8 md:px-16 w-full md:w-1/2">
                <h1 className="text-white text-3xl md:text-4xl font-bold mb-4">{slide.title}</h1>
                <p className="text-white/90 mb-6">{slide.description}</p>
                <Button asChild className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg font-medium">
                  <Link href={slide.ctaLink}>
                    {slide.ctaText} <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Slider Navigation Arrows */}
      <button 
        onClick={prevSlide}
        className="absolute top-1/2 left-4 -translate-y-1/2 bg-white/20 hover:bg-white/40 rounded-full p-2 text-white transition"
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-6 w-6" />
      </button>
      
      <button 
        onClick={nextSlide}
        className="absolute top-1/2 right-4 -translate-y-1/2 bg-white/20 hover:bg-white/40 rounded-full p-2 text-white transition"
        aria-label="Next slide"
      >
        <ChevronRight className="h-6 w-6" />
      </button>
      
      {/* Slider Controls */}
      <div className="absolute bottom-4 right-4 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full ${
              index === currentSlide ? 'bg-white' : 'bg-white/40'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          ></button>
        ))}
      </div>
    </div>
  );
};

export default Hero;
