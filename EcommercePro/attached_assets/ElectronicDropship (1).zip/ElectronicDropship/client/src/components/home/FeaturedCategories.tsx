import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Smartphone, Headphones, Watch, Laptop } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

// Icons for categories
const categoryIcons: Record<string, React.ReactNode> = {
  smartphones: <Smartphone className="text-white text-2xl" />,
  audio: <Headphones className="text-white text-2xl" />,
  wearables: <Watch className="text-white text-2xl" />,
  accessories: <Laptop className="text-white text-2xl" />,
};

// Background colors for categories
const categoryBgColors: Record<string, string> = {
  smartphones: "from-blue-500 to-blue-700",
  audio: "from-purple-500 to-purple-700",
  wearables: "from-green-500 to-green-700",
  accessories: "from-amber-500 to-amber-700",
};

const FeaturedCategories = () => {
  const { data: categories, isLoading, error } = useQuery({
    queryKey: ["/api/categories"],
  });

  if (isLoading) {
    return (
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-6">Categorias em Destaque</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-40 rounded-xl" />
          ))}
        </div>
      </section>
    );
  }

  if (error || !categories) {
    return (
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-6">Categorias em Destaque</h2>
        <div className="bg-red-50 p-4 rounded-lg text-red-500">
          Erro ao carregar categorias.
        </div>
      </section>
    );
  }

  // Filter to show only 4 categories
  const featuredCategories = categories.slice(0, 4);

  return (
    <section className="mb-12">
      <h2 className="text-2xl font-semibold mb-6">Categorias em Destaque</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {featuredCategories.map((category: any) => (
          <Link href={`/category/${category.slug}`} key={category.id}>
            <div className={`bg-gradient-to-br ${categoryBgColors[category.slug] || "from-gray-500 to-gray-700"} rounded-xl overflow-hidden relative h-40 shadow-md transition-transform hover:scale-[1.02]`}>
              <img 
                src={category.imageUrl} 
                alt={category.name} 
                className="w-full h-full object-cover mix-blend-overlay opacity-50"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-2">
                    {categoryIcons[category.slug] || <Smartphone className="text-white text-2xl" />}
                  </div>
                  <h3 className="font-semibold text-white">{category.name}</h3>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
};

export default FeaturedCategories;
