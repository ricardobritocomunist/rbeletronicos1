import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

const PromoBanner = () => {
  return (
    <div className="mb-12 bg-gradient-to-r from-primary to-blue-700 rounded-xl overflow-hidden shadow-lg">
      <div className="flex flex-col md:flex-row items-center">
        <div className="p-8 md:p-12 md:w-1/2">
          <span className="bg-white/20 text-white px-4 py-1 rounded-full text-sm font-medium mb-4 inline-block">Oferta Exclusiva</span>
          <h2 className="text-white text-3xl font-bold mb-4">Até 30% de desconto em acessórios para smartphones</h2>
          <p className="text-white/80 mb-6">Aproveite preços especiais em capas, carregadores, películas e muito mais. Oferta por tempo limitado!</p>
          <Link href="/category/accessories">
            <a className="bg-white text-primary hover:bg-gray-100 px-6 py-3 rounded-lg font-medium inline-flex items-center">
              Comprar agora <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Link>
        </div>
        <div className="md:w-1/2 relative h-64 md:h-auto">
          <img 
            src="https://images.unsplash.com/photo-1491933382434-500287f9b54b" 
            alt="Acessórios para smartphones em promoção" 
            className="h-full w-full object-cover" 
          />
        </div>
      </div>
    </div>
  );
};

export default PromoBanner;
