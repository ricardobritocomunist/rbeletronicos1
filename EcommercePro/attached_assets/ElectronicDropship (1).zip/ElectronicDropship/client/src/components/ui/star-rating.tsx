import { Star, StarHalf } from "lucide-react";

interface StarRatingProps {
  rating: number;
  reviews?: number;
  size?: "sm" | "md" | "lg";
  showReviews?: boolean;
}

const StarRating = ({
  rating,
  reviews,
  size = "sm",
  showReviews = true,
}: StarRatingProps) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStar = 5 - fullStars - (hasHalfStar ? 1 : 0);
  
  const getStarSize = () => {
    switch (size) {
      case "sm":
        return "h-4 w-4";
      case "md":
        return "h-5 w-5";
      case "lg":
        return "h-6 w-6";
      default:
        return "h-4 w-4";
    }
  };
  
  const starSize = getStarSize();
  
  return (
    <div className="flex items-center">
      <div className="text-yellow-400 flex">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`full-${i}`} className={`${starSize} fill-current`} />
        ))}
        
        {hasHalfStar && (
          <StarHalf className={`${starSize} fill-current`} />
        )}
        
        {[...Array(emptyStar)].map((_, i) => (
          <Star key={`empty-${i}`} className={`${starSize} text-gray-300`} />
        ))}
      </div>
      
      {showReviews && reviews !== undefined && (
        <span className="text-gray-500 ml-1 text-sm">({reviews})</span>
      )}
    </div>
  );
};

export default StarRating;
