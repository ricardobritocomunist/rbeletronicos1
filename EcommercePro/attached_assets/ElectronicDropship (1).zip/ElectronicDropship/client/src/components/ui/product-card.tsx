import { useState } from "react";
import { Link } from "wouter";
import { Heart, ShoppingCart } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import StarRating from "@/components/ui/star-rating";
import { useCart } from "@/context/CartContext";
import { formatCurrency } from "@/lib/utils";

interface ProductCardProps {
  product: {
    id: number;
    slug: string;
    name: string;
    description: string;
    price: number;
    compareAtPrice?: number;
    image: string;
    rating: number;
    numReviews: number;
    isNew?: boolean;
    isFeatured?: boolean;
  };
}

const ProductCard = ({ product }: ProductCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const { addToCart } = useCart();
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product.id);
  };
  
  const handleAddToWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Add wishlist functionality here
  };
  
  const getDiscountPercentage = () => {
    if (!product.compareAtPrice) return null;
    const discount = Math.round(
      ((product.compareAtPrice - product.price) / product.compareAtPrice) * 100
    );
    return `-${discount}%`;
  };
  
  const discountBadge = getDiscountPercentage();
  
  return (
    <div 
      className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link href={`/products/${product.slug}`}>
        <div className="relative">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-48 object-cover"
          />
          <div className="absolute top-2 left-2">
            {product.isNew && (
              <Badge className="bg-accent text-white text-xs px-2 py-1 rounded-full">
                Novo
              </Badge>
            )}
            {discountBadge && (
              <Badge className="bg-secondary text-white text-xs px-2 py-1 rounded-full ml-1">
                {discountBadge}
              </Badge>
            )}
            {product.isFeatured && !product.isNew && !discountBadge && (
              <Badge className="bg-primary text-white text-xs px-2 py-1 rounded-full">
                Top
              </Badge>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 bg-white rounded-full p-2 text-neutral-dark hover:text-primary shadow-sm"
            onClick={handleAddToWishlist}
          >
            <Heart className="h-5 w-5" />
          </Button>
        </div>
        <div className="p-4">
          <div className="mb-1">
            <StarRating rating={product.rating} reviews={product.numReviews} />
          </div>
          <h3 className="font-medium mb-1 hover:text-primary truncate">{product.name}</h3>
          <p className="text-gray-500 text-sm mb-2 line-clamp-2">{product.description}</p>
          <div className="flex justify-between items-center">
            <div>
              {product.compareAtPrice && (
                <span className="line-through text-gray-400 text-sm">
                  {formatCurrency(product.compareAtPrice)}
                </span>
              )}
              <p className="font-semibold text-lg">{formatCurrency(product.price)}</p>
            </div>
            <Button
              className="bg-primary hover:bg-primary/90 text-white rounded-lg p-2"
              size="icon"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;
