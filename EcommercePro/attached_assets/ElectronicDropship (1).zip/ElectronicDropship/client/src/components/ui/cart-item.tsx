import { useState } from "react";
import { Link } from "wouter";
import { Trash2, Plus, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { formatCurrency } from "@/lib/utils";

interface CartItemProps {
  item: {
    cartItem: {
      id: number;
      productId: number;
      quantity: number;
    };
    product: {
      id: number;
      slug: string;
      name: string;
      price: number;
      image: string;
    };
  };
}

const CartItem = ({ item }: CartItemProps) => {
  const { updateCartItemQuantity, removeFromCart } = useCart();
  const [isUpdating, setIsUpdating] = useState(false);
  
  const handleIncreaseQuantity = async () => {
    setIsUpdating(true);
    await updateCartItemQuantity(item.cartItem.id, item.cartItem.quantity + 1);
    setIsUpdating(false);
  };
  
  const handleDecreaseQuantity = async () => {
    if (item.cartItem.quantity > 1) {
      setIsUpdating(true);
      await updateCartItemQuantity(item.cartItem.id, item.cartItem.quantity - 1);
      setIsUpdating(false);
    }
  };
  
  const handleRemove = async () => {
    await removeFromCart(item.cartItem.id);
  };
  
  return (
    <div className="flex items-center space-x-4 bg-gray-50 p-3 rounded-lg">
      <Link href={`/products/${item.product.slug}`}>
        <img 
          src={item.product.image} 
          alt={item.product.name} 
          className="w-20 h-20 object-cover rounded-md"
        />
      </Link>
      <div className="flex-1">
        <Link href={`/products/${item.product.slug}`}>
          <h4 className="font-medium hover:text-primary">{item.product.name}</h4>
        </Link>
        <p className="text-gray-500 text-sm">{formatCurrency(item.product.price)}</p>
        <div className="flex items-center mt-2">
          <Button
            variant="outline"
            size="icon"
            className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center p-0 border-0"
            onClick={handleDecreaseQuantity}
            disabled={item.cartItem.quantity <= 1 || isUpdating}
          >
            <Minus className="h-3 w-3" />
          </Button>
          <span className="mx-2">{item.cartItem.quantity}</span>
          <Button
            variant="outline"
            size="icon"
            className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center p-0 border-0"
            onClick={handleIncreaseQuantity}
            disabled={isUpdating}
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="text-gray-400 hover:text-destructive"
        onClick={handleRemove}
        disabled={isUpdating}
      >
        <Trash2 className="h-5 w-5" />
      </Button>
    </div>
  );
};

export default CartItem;
