import { Link } from "wouter";
import { Smartphone, Headphones, Watch, Package } from "lucide-react";

interface CategoryCardProps {
  category: {
    id: number;
    name: string;
    slug: string;
    image: string;
  };
}

const CategoryCard = ({ category }: CategoryCardProps) => {
  const getIconByName = (name: string) => {
    switch (name.toLowerCase()) {
      case "smartphones":
        return <Smartphone className="text-white text-2xl" />;
      case "audio":
        return <Headphones className="text-white text-2xl" />;
      case "wearables":
        return <Watch className="text-white text-2xl" />;
      default:
        return <Package className="text-white text-2xl" />;
    }
  };
  
  const getGradientByName = (name: string) => {
    switch (name.toLowerCase()) {
      case "smartphones":
        return "from-blue-500 to-blue-700";
      case "audio":
        return "from-purple-500 to-purple-700";
      case "wearables":
        return "from-green-500 to-green-700";
      default:
        return "from-amber-500 to-amber-700";
    }
  };
  
  return (
    <Link href={`/products/category/${category.slug}`}>
      <div 
        className={`bg-gradient-to-br ${getGradientByName(category.name)} rounded-xl overflow-hidden relative h-40 shadow-md transition-transform hover:scale-[1.02]`}
      >
        <img 
          src={category.image} 
          alt={category.name} 
          className="w-full h-full object-cover mix-blend-overlay opacity-50"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-2">
              {getIconByName(category.name)}
            </div>
            <h3 className="font-semibold text-white">{category.name}</h3>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default CategoryCard;
