import { Truck, CreditCard, Shield, Headset } from "lucide-react";

const features = [
  {
    icon: <Truck className="text-primary text-xl" />,
    title: "Envio Rápido",
    description: "Entrega em todo o Brasil",
  },
  {
    icon: <CreditCard className="text-primary text-xl" />,
    title: "Pagamento Seguro",
    description: "Múltiplas formas de pagamento",
  },
  {
    icon: <Shield className="text-primary text-xl" />,
    title: "Garantia",
    description: "12 meses em todos produtos",
  },
  {
    icon: <Headset className="text-primary text-xl" />,
    title: "Suporte 24/7",
    description: "Atendimento especializado",
  },
];

const Features = () => {
  return (
    <section className="mb-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature, index) => (
          <div
            key={index}
            className="bg-white p-6 rounded-xl shadow-md flex items-center"
          >
            <div className="bg-primary/10 rounded-full p-4 mr-4">
              {feature.icon}
            </div>
            <div>
              <h3 className="font-semibold mb-1">{feature.title}</h3>
              <p className="text-gray-600 text-sm">{feature.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Features;
