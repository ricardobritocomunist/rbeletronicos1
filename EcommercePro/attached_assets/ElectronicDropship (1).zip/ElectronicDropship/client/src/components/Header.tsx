import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { BoltIcon, SearchIcon, HeartIcon, ShoppingCartIcon, UserIcon, MenuIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";

const Header = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { openCart, cartItems } = useCart();
  const { isAuthenticated, user } = useAuth();
  const [location, navigate] = useLocation();
  
  // Get categories
  interface Category {
    id: number;
    name: string;
    slug: string;
  }
  
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    enabled: true,
  });
  
  // Handle search submit
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery("");
    }
  };
  
  // Close mobile menu when location changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);
  
  // Calculate total items in cart
  const cartItemsCount = cartItems.reduce((total, item) => total + item.cartItem.quantity, 0);
  
  // Check if a category is active
  const isCategoryActive = (slug: string) => {
    return location === `/products/category/${slug}`;
  };
  
  return (
    <header className="bg-black shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <Link href="/" className="flex items-center">
              <BoltIcon className="text-brand-red h-6 w-6" />
              <span className="ml-2 text-xl font-bold text-white">Tech<span className="text-brand-red">Drop</span></span>
            </Link>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 mx-8">
            <form onSubmit={handleSearchSubmit} className="relative w-full">
              <Input
                type="text"
                placeholder="Buscar produtos..."
                className="w-full px-4 py-2 border border-gray-700 text-black rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button
                type="submit"
                variant="ghost"
                className="absolute right-0 top-0 bottom-0 px-4 text-gray-600 hover:text-brand-red"
              >
                <SearchIcon className="h-5 w-5" />
              </Button>
            </form>
          </div>

          {/* Navigation Icons */}
          <div className="flex items-center space-x-6">
            <Link href="/wishlist" className="text-white hover:text-brand-red relative">
              <HeartIcon className="h-6 w-6" />
              <Badge className="absolute -top-2 -right-2 bg-brand-red text-white px-1 min-w-[20px] h-5 flex items-center justify-center text-xs">
                0
              </Badge>
            </Link>
            <button 
              onClick={openCart}
              className="text-white hover:text-brand-red relative"
            >
              <ShoppingCartIcon className="h-6 w-6" />
              {cartItemsCount > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-brand-red text-white px-1 min-w-[20px] h-5 flex items-center justify-center text-xs">
                  {cartItemsCount}
                </Badge>
              )}
            </button>
            {isAuthenticated ? (
              <Link href="/profile" className="text-white hover:text-brand-red">
                <UserIcon className="h-6 w-6" />
              </Link>
            ) : (
              <Link href="/login" className="text-white hover:text-brand-red">
                <UserIcon className="h-6 w-6" />
              </Link>
            )}
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden pb-4">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <Input
              type="text"
              placeholder="Buscar produtos..."
              className="w-full px-4 py-2 border border-gray-700 text-black rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button
              type="submit"
              variant="ghost"
              className="absolute right-0 top-0 bottom-0 px-4 text-gray-600 hover:text-brand-red"
            >
              <SearchIcon className="h-5 w-5" />
            </Button>
          </form>
        </div>

        {/* Categories Navigation */}
        <nav className="border-t border-gray-600 overflow-x-auto scrollbar-hide">
          <ul className="flex space-x-8 py-3 text-sm font-medium">
            <li>
              <Link
                href="/products"
                className={`whitespace-nowrap ${
                  location === "/products" ? "text-brand-red border-b-2 border-brand-red pb-3" : "text-white hover:text-brand-red pb-3"
                }`}
              >
                Todos
              </Link>
            </li>
            {categories.map((category) => (
              <li key={category.id}>
                <Link
                  href={`/products/category/${category.slug}`}
                  className={`whitespace-nowrap ${
                    isCategoryActive(category.slug) ? "text-brand-red border-b-2 border-brand-red pb-3" : "text-white hover:text-brand-red pb-3"
                  }`}
                >
                  {category.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
