import { ReactNode, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Users, 
  Settings, 
  LogOut, 
  Menu,
  X,
  Home
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";

interface AdminLayoutProps {
  children: ReactNode;
  title: string;
}

const AdminLayout = ({ children, title }: AdminLayoutProps) => {
  const { user, logout, isAdmin, isAuthenticated, isLoading } = useAuth();
  const [location, navigate] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Protect admin routes
  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        navigate("/login?redirect=/admin");
      } else if (!isAdmin) {
        navigate("/");
      }
    }
  }, [isAdmin, isAuthenticated, isLoading, navigate]);

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!isAuthenticated || !isAdmin) {
    return null; // Will redirect in the useEffect
  }

  const navItems = [
    { href: "/admin", label: "Dashboard", icon: <LayoutDashboard className="h-5 w-5" /> },
    { href: "/admin/products", label: "Produtos", icon: <Package className="h-5 w-5" /> },
    { href: "/admin/orders", label: "Pedidos", icon: <ShoppingCart className="h-5 w-5" /> },
    { href: "/admin/users", label: "Usuários", icon: <Users className="h-5 w-5" /> },
  ];

  const isActive = (path: string) => {
    return location === path;
  };
  
  // Navigation component for both desktop sidebar and mobile drawer
  const Navigation = () => (
    <nav className="space-y-1">
      {navItems.map((item) => (
        <Link key={item.href} href={item.href}>
          <a
            className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${
              isActive(item.href)
                ? "bg-primary text-white font-medium"
                : "text-gray-700 hover:bg-gray-100"
            }`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            {item.icon}
            <span>{item.label}</span>
          </a>
        </Link>
      ))}
    </nav>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200 p-4">
        <div className="flex items-center space-x-2 mb-8">
          <svg viewBox="0 0 24 24" className="text-primary w-6 h-6" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
            <path d="M13 3l0 7l6 0l-8 11l0 -7l-6 0l8 -11"></path>
          </svg>
          <span className="text-xl font-bold text-neutral-dark">Tech<span className="text-primary">Drop</span></span>
        </div>
        
        <Navigation />
        
        <div className="mt-auto pt-4">
          <Separator className="mb-4" />
          <Link href="/">
            <a className="flex items-center space-x-3 px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100 mb-4">
              <Home className="h-5 w-5" />
              <span>Visitar Loja</span>
            </a>
          </Link>
          
          <div className="flex items-center justify-between px-3 py-2">
            <div className="flex items-center space-x-3">
              <Avatar className="h-8 w-8">
                <AvatarFallback>{user?.name?.[0] ?? "A"}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-gray-500">{user?.email}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              className="text-gray-500 hover:text-red-500"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Mobile Menu */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetContent side="left" className="w-64 p-4">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2">
                <svg viewBox="0 0 24 24" className="text-primary w-6 h-6" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                  <path d="M13 3l0 7l6 0l-8 11l0 -7l-6 0l8 -11"></path>
                </svg>
                <span className="text-xl font-bold text-neutral-dark">Tech<span className="text-primary">Drop</span></span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
            
            <Navigation />
            
            <div className="mt-auto pt-4">
              <Separator className="mb-4" />
              <Link href="/">
                <a
                  className="flex items-center space-x-3 px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100 mb-4"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Home className="h-5 w-5" />
                  <span>Visitar Loja</span>
                </a>
              </Link>
              
              <div className="flex items-center justify-between px-3 py-2">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{user?.name?.[0] ?? "A"}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-gray-500">{user?.email}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleLogout}
                  className="text-gray-500 hover:text-red-500"
                >
                  <LogOut className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 py-4 px-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </Button>
            <h1 className="text-xl font-semibold">{title}</h1>
          </div>
          
          <div className="md:hidden flex items-center space-x-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback>{user?.name?.[0] ?? "A"}</AvatarFallback>
            </Avatar>
          </div>
        </header>
        
        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
