import { Link, useLocation } from "wouter";
import { Home, Search, ShoppingCart, Heart, User } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";

const MobileNavbar = () => {
  const [location] = useLocation();
  const { openCart, cartItems } = useCart();
  const { isAuthenticated } = useAuth();
  
  const cartItemsCount = cartItems.reduce((total, item) => total + item.cartItem.quantity, 0);
  
  const isActive = (path: string) => {
    return location === path ? "text-brand-red" : "text-gray-500 hover:text-brand-red";
  };
  
  const profileLink = isAuthenticated ? "/profile" : "/login";
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-700 py-2 md:hidden z-40">
      <div className="flex justify-around items-center">
        <Link href="/" className={`flex flex-col items-center ${isActive("/")}`}>
          <Home className="h-5 w-5" />
          <span className="text-xs mt-1 text-white">Início</span>
        </Link>
        <Link href="/products" className={`flex flex-col items-center ${isActive("/products")}`}>
          <Search className="h-5 w-5" />
          <span className="text-xs mt-1 text-white">Buscar</span>
        </Link>
        <button
          onClick={openCart}
          className="flex flex-col items-center text-gray-500 hover:text-brand-red"
        >
          <div className="relative">
            <ShoppingCart className="h-5 w-5" />
            {cartItemsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-brand-red text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px]">
                {cartItemsCount > 9 ? "9+" : cartItemsCount}
              </span>
            )}
          </div>
          <span className="text-xs mt-1 text-white">Carrinho</span>
        </button>
        <Link href="/wishlist" className={`flex flex-col items-center ${isActive("/wishlist")}`}>
          <Heart className="h-5 w-5" />
          <span className="text-xs mt-1 text-white">Favoritos</span>
        </Link>
        <Link href={profileLink} className={`flex flex-col items-center ${isActive(profileLink)}`}>
          <User className="h-5 w-5" />
          <span className="text-xs mt-1 text-white">Conta</span>
        </Link>
      </div>
    </div>
  );
};

export default MobileNavbar;
