import { Link } from "wouter";
import { BoltIcon, MapPinIcon, PhoneIcon, MailIcon, ClockIcon, CreditCard } from "lucide-react";
import { FaFacebookF, FaInstagram, FaTwitter, FaYoutube } from "react-icons/fa";
import { SiVisa, SiMastercard, SiAmericanexpress } from "react-icons/si";

const Footer = () => {
  return (
    <footer className="bg-black text-white border-t border-gray-700 pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <BoltIcon className="text-brand-red h-6 w-6" />
              <span className="text-xl font-bold text-white">Tech<span className="text-brand-red">Drop</span></span>
            </div>
            <p className="text-gray-400 mb-4">
              Sua loja online de eletrônicos com os melhores preços e produtos de qualidade.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-brand-red">
                <FaFacebookF />
              </a>
              <a href="#" className="text-gray-400 hover:text-brand-red">
                <FaInstagram />
              </a>
              <a href="#" className="text-gray-400 hover:text-brand-red">
                <FaTwitter />
              </a>
              <a href="#" className="text-gray-400 hover:text-brand-red">
                <FaYoutube />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white">Links Rápidos</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-400 hover:text-brand-red">Sobre Nós</Link></li>
              <li><Link href="/products" className="text-gray-400 hover:text-brand-red">Produtos</Link></li>
              <li><Link href="/products?featured=true" className="text-gray-400 hover:text-brand-red">Ofertas</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-brand-red">Contato</Link></li>
              <li><Link href="/faq" className="text-gray-400 hover:text-brand-red">FAQ</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white">Categorias</h3>
            <ul className="space-y-2">
              <li><Link href="/products/category/smartphones" className="text-gray-400 hover:text-brand-red">Smartphones</Link></li>
              <li><Link href="/products/category/audio" className="text-gray-400 hover:text-brand-red">Fones de Ouvido</Link></li>
              <li><Link href="/products/category/wearables" className="text-gray-400 hover:text-brand-red">Smartwatches</Link></li>
              <li><Link href="/products/category/accessories" className="text-gray-400 hover:text-brand-red">Acessórios</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white">Contato</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPinIcon className="text-brand-red h-5 w-5 mt-1 mr-3" />
                <span className="text-gray-400">Av. Paulista, 1000, São Paulo - SP</span>
              </li>
              <li className="flex items-start">
                <PhoneIcon className="text-brand-red h-5 w-5 mt-1 mr-3" />
                <span className="text-gray-400">(11) 99999-9999</span>
              </li>
              <li className="flex items-start">
                <MailIcon className="text-brand-red h-5 w-5 mt-1 mr-3" />
                <span className="text-gray-400">contato@techdrop.com.br</span>
              </li>
              <li className="flex items-start">
                <ClockIcon className="text-brand-red h-5 w-5 mt-1 mr-3" />
                <span className="text-gray-400">Seg-Sex: 9h às 18h</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">© 2023 TechDrop. Todos os direitos reservados.</p>
            <div className="flex items-center space-x-4">
              <SiVisa className="h-8 w-8 text-white" />
              <SiMastercard className="h-8 w-8 text-white" />
              <SiAmericanexpress className="h-8 w-8 text-white" />
              <CreditCard className="h-8 w-8 text-brand-red" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
