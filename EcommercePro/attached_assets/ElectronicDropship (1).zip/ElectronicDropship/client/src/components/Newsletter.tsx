import { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { newsletterSchema } from "@/lib/validators";

type FormData = z.infer<typeof newsletterSchema>;

const Newsletter = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(newsletterSchema),
    defaultValues: {
      email: '',
    },
  });

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      // In a real application, you would send this to an API endpoint
      // await apiRequest("POST", "/api/newsletter", data);
      
      toast({
        title: "Inscrição realizada!",
        description: "Você receberá nossas ofertas exclusivas no email informado.",
      });
      
      form.reset();
    } catch (error) {
      toast({
        title: "Erro na inscrição",
        description: "Ocorreu um erro ao processar sua inscrição. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="mb-12 bg-neutral-dark rounded-xl overflow-hidden">
      <div className="p-8 md:p-12">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-white text-2xl md:text-3xl font-bold mb-3">
            Inscreva-se e ganhe 10% de desconto
          </h2>
          <p className="text-white/80 mb-6">
            Receba nossas ofertas exclusivas e novidades diretamente no seu e-mail.
          </p>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormControl>
                      <Input 
                        type="email" 
                        placeholder="Seu e-mail" 
                        className="px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage className="text-red-300 text-xs mt-1 text-left" />
                  </FormItem>
                )}
              />
              
              <Button 
                type="submit" 
                className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg font-medium"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Processando..." : "Quero receber ofertas"}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
