import { Link } from "wouter";
import { Heart, ShoppingCart, Star, StarHalf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

interface ProductCardProps {
  product: {
    id: number;
    name: string;
    slug: string;
    description: string;
    price: number;
    compareAtPrice?: number;
    imageUrl?: string;
    rating: number;
    numReviews: number;
    isNew?: boolean;
    isFeatured?: boolean;
    stock: number;
  };
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    setIsAddingToCart(true);
    try {
      await addToCart(product.id, 1);
    } catch (error) {
      console.error("Error adding to cart:", error);
    } finally {
      setIsAddingToCart(false);
    }
  };

  const handleAddToWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    toast({
      title: "Adicionado aos favoritos",
      description: "Produto adicionado à sua lista de desejos",
    });
  };

  // Helper function to render stars based on rating
  const renderRatingStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-yellow-400 text-yellow-400" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="fill-yellow-400 text-yellow-400" />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-star-${i}`} className="text-gray-300" />);
    }
    
    return stars;
  };

  let badge = null;
  if (product.isNew) {
    badge = <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">Novo</span>;
  } else if (product.compareAtPrice) {
    const discount = Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100);
    badge = <span className="bg-amber-500 text-white text-xs px-2 py-1 rounded-full">-{discount}%</span>;
  } else if (product.isFeatured) {
    badge = <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">Top</span>;
  }

  return (
    <Link href={`/product/${product.slug}`}>
      <a className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all block">
        <div className="relative">
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-48 object-cover"
            onError={(e) => {
              e.currentTarget.src = "https://via.placeholder.com/400x300?text=Imagem+Indisponível";
            }}
          />
          {badge && (
            <div className="absolute top-2 left-2">
              {badge}
            </div>
          )}
          <Button
            variant="outline"
            size="icon"
            className="absolute top-2 right-2 bg-white rounded-full p-2 text-neutral-dark hover:text-primary shadow-sm"
            onClick={handleAddToWishlist}
          >
            <Heart className="h-4 w-4" />
          </Button>
        </div>
        <div className="p-4">
          <div className="flex text-sm mb-1 items-center">
            <div className="flex space-x-0.5">
              {renderRatingStars(product.rating)}
            </div>
            <span className="text-gray-500 ml-1">({product.numReviews})</span>
          </div>
          <h3 className="font-medium mb-1 hover:text-primary truncate">{product.name}</h3>
          <p className="text-gray-500 text-sm mb-2 line-clamp-2">{product.description}</p>
          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold text-lg">
                R${product.price.toFixed(2).replace('.', ',')}
              </p>
            </div>
            <Button
              size="icon"
              className="bg-primary hover:bg-primary/90 text-white rounded-lg"
              onClick={handleAddToCart}
              disabled={isAddingToCart || product.stock <= 0}
            >
              <ShoppingCart className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </a>
    </Link>
  );
};

export default ProductCard;
