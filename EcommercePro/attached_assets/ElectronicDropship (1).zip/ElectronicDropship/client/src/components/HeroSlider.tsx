import { useState, useEffect } from "react";
import { Link } from "wouter";
import { ChevronLeft, ChevronRight, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Slide {
  id: number;
  title: string;
  description: string;
  image: string;
  link: string;
}

const slides: Slide[] = [
  {
    id: 1,
    title: "Tecnologia de ponta, ao seu alcance",
    description: "Descubra os últimos gadgets e acessórios com os melhores preços do mercado.",
    image: "https://images.unsplash.com/photo-1526738549149-8e07eca6c147?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=600",
    link: "/products?featured=true"
  },
  {
    id: 2,
    title: "Áudio de alta definição",
    description: "Experimente qualidade sonora premium com nossos fones de ouvido e caixas de som.",
    image: "https://images.unsplash.com/photo-1546435770-a3e429dcb388?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=600",
    link: "/products/category/audio"
  },
  {
    id: 3,
    title: "Monitore sua saúde e fitness",
    description: "Smartwatches e wearables para acompanhar sua atividade física e bem-estar.",
    image: "https://images.unsplash.com/photo-1544117519-31a4a9dba7c2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=600",
    link: "/products/category/wearables"
  }
];

const HeroSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const goToNextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
  };
  
  const goToPrevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };
  
  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };
  
  // Auto slide every 5 seconds
  useEffect(() => {
    const interval = setInterval(goToNextSlide, 5000);
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="relative rounded-xl overflow-hidden mb-10 shadow-lg h-[400px]">
      {/* Slider Images */}
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-500 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <img
            src={slide.image}
            alt={slide.title}
            className="w-full h-full object-cover"
          />
          
          {/* Content Overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex items-center">
            <div className="px-8 md:px-16 w-full md:w-1/2">
              <h1 className="text-white text-3xl md:text-4xl font-bold mb-4">
                {slide.title}
              </h1>
              <p className="text-white/90 mb-6">{slide.description}</p>
              <Link href={slide.link}>
                <Button className="bg-primary hover:bg-primary/90 text-white px-6 py-3">
                  Ver ofertas <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      ))}
      
      {/* Navigation Arrows */}
      <Button
        variant="ghost"
        className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white bg-black/30 hover:bg-black/50 rounded-full p-2"
        onClick={goToPrevSlide}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>
      
      <Button
        variant="ghost"
        className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white bg-black/30 hover:bg-black/50 rounded-full p-2"
        onClick={goToNextSlide}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>
      
      {/* Slider Controls */}
      <div className="absolute bottom-4 right-4 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`w-3 h-3 rounded-full ${
              index === currentSlide ? "bg-white" : "bg-white/40"
            }`}
            onClick={() => goToSlide(index)}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroSlider;
