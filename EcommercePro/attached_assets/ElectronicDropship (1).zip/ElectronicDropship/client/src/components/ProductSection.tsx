import { useState, useEffect } from "react";
import { Link } from "wouter";
import { ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import ProductCard from "@/components/ui/product-card";
import { Skeleton } from "@/components/ui/skeleton";

interface ProductSectionProps {
  title: string;
  endpoint: string;
  viewAllLink: string;
}

const ProductSection = ({
  title,
  endpoint,
  viewAllLink,
}: ProductSectionProps) => {
  const { data: products, isLoading } = useQuery({
    queryKey: [endpoint],
  });

  const LoadingSkeleton = () => (
    <div className="product-grid">
      {[...Array(4)].map((_, i) => (
        <div key={i} className="bg-white rounded-xl overflow-hidden shadow-md">
          <Skeleton className="w-full h-48" />
          <div className="p-4">
            <Skeleton className="h-4 w-24 mb-1" />
            <Skeleton className="h-5 w-40 mb-1" />
            <Skeleton className="h-4 w-full mb-2" />
            <div className="flex justify-between items-center">
              <Skeleton className="h-6 w-20" />
              <Skeleton className="h-10 w-10 rounded-lg" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <section className="mb-12">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold">{title}</h2>
        <Link
          href={viewAllLink}
          className="text-primary hover:underline flex items-center text-sm font-medium"
        >
          Ver todos <ChevronRight className="ml-1 h-4 w-4" />
        </Link>
      </div>

      {isLoading ? (
        <LoadingSkeleton />
      ) : products && products.length > 0 ? (
        <div className="product-grid">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="bg-gray-100 p-8 rounded-lg text-center">
          <p className="text-gray-600">Nenhum produto encontrado.</p>
        </div>
      )}
    </section>
  );
};

export default ProductSection;
