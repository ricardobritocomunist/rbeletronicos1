import { ReactNode, useEffect } from "react";
import Header from "./Header";
import Footer from "./Footer";
import MobileNavbar from "./MobileNavbar";
import CartSidebar from "./CartSidebar";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { useLocation } from "wouter";

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const { isCartOpen, closeCart, fetchCart } = useCart();
  const { checkAuth, isAuthenticated } = useAuth();
  const [location] = useLocation();
  
  // Check authentication status when component mounts
  useEffect(() => {
    checkAuth();
  }, [checkAuth]);
  
  // Fetch cart data when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchCart();
    }
  }, [isAuthenticated, fetchCart]);
  
  // Close cart when location changes
  useEffect(() => {
    closeCart();
  }, [location, closeCart]);
  
  const isAdminPage = location.startsWith("/admin");
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Only show header on non-admin pages */}
      {!isAdminPage && <Header />}
      
      <main className={`flex-grow ${isAdminPage ? '' : 'container mx-auto px-4 py-8'}`}>
        {children}
      </main>
      
      {!isAdminPage && (
        <>
          <Footer />
          <MobileNavbar />
          {isCartOpen && <CartSidebar />}
        </>
      )}
    </div>
  );
};

export default Layout;
