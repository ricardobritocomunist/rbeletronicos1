import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import CartItem from "@/components/ui/cart-item";
import { useCart } from "@/context/CartContext";
import { formatCurrency } from "@/lib/utils";
import { Link } from "wouter";

const CartSidebar = () => {
  const { closeCart, cartItems, isLoading, clearCart } = useCart();
  
  // Calculate subtotal
  const subtotal = cartItems.reduce(
    (total, item) => total + item.product.price * item.cartItem.quantity,
    0
  );
  
  // Shipping is free for orders over R$199
  const shippingCost = subtotal > 199 ? 0 : 15.9;
  
  // Total cost
  const total = subtotal + shippingCost;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={closeCart}>
      <div 
        className="absolute right-0 top-0 bottom-0 bg-black text-white w-full max-w-md shadow-xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h3 className="font-semibold text-lg text-white">
            Seu Carrinho ({cartItems.length} {cartItems.length === 1 ? "item" : "itens"})
          </h3>
          <Button variant="ghost" size="icon" onClick={closeCart} className="text-white hover:text-brand-red">
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        {isLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="animate-spin h-8 w-8 border-4 border-brand-red border-t-transparent rounded-full"></div>
          </div>
        ) : cartItems.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-4">
            <div className="bg-gray-800 rounded-full p-6 mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8 text-gray-400">
                <circle cx="8" cy="21" r="1"></circle>
                <circle cx="19" cy="21" r="1"></circle>
                <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path>
              </svg>
            </div>
            <h4 className="text-lg font-medium mb-2 text-white">Seu carrinho está vazio</h4>
            <p className="text-gray-400 text-center mb-6">Parece que você ainda não adicionou nenhum produto ao seu carrinho.</p>
            <Button className="bg-brand-red hover:bg-brand-red/90" onClick={closeCart}>
              Continuar Comprando
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {cartItems.map((item) => (
                <CartItem key={item.cartItem.id} item={item} />
              ))}
            </div>
            
            <div className="p-4 border-t border-gray-700">
              <div className="flex justify-between mb-2">
                <span className="text-gray-400">Subtotal</span>
                <span className="font-semibold text-white">{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between mb-4">
                <span className="text-gray-400">Frete</span>
                <span className="font-semibold text-white">
                  {shippingCost === 0 ? "Grátis" : formatCurrency(shippingCost)}
                </span>
              </div>
              <div className="flex justify-between mb-6 text-lg">
                <span className="font-semibold text-white">Total</span>
                <span className="font-bold text-white">{formatCurrency(total)}</span>
              </div>
              
              <Link href="/checkout">
                <Button 
                  className="bg-brand-red hover:bg-brand-red/90 text-white py-3 rounded-lg font-medium w-full mb-3"
                >
                  Finalizar Compra
                </Button>
              </Link>
              
              <Button 
                variant="outline"
                className="border-gray-700 text-white hover:text-white hover:bg-gray-800 w-full"
                onClick={closeCart}
              >
                Continuar Comprando
              </Button>
              
              {cartItems.length > 0 && (
                <Button 
                  variant="ghost"
                  className="text-red-400 hover:text-white hover:bg-red-900 w-full mt-2"
                  onClick={clearCart}
                >
                  Limpar Carrinho
                </Button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CartSidebar;
