import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useCart } from "@/lib/cart";
import CartSidebar from "@/components/cart/CartSidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Search, 
  Heart, 
  ShoppingCart, 
  User, 
  LogOut, 
  Menu,
  X
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const Header = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [location, navigate] = useLocation();
  const { isAuthenticated, user, logout, isAdmin } = useAuth();
  const { cartCount } = useCart();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Get categories for navigation
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  const handleLogout = async () => {
    await logout();
  };

  return (
    <>
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            {/* Logo */}
            <div className="flex items-center space-x-2">
              <Link href="/" className="flex items-center">
                <svg viewBox="0 0 24 24" className="text-primary w-6 h-6" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                  <path d="M13 3l0 7l6 0l-8 11l0 -7l-6 0l8 -11"></path>
                </svg>
                <span className="ml-2 text-xl font-bold text-neutral-dark">Tech<span className="text-primary">Drop</span></span>
              </Link>
            </div>

            {/* Search Bar - Desktop */}
            <div className="hidden md:flex flex-1 mx-8">
              <form onSubmit={handleSearch} className="relative w-full">
                <Input
                  type="text"
                  placeholder="Buscar produtos..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Button
                  type="submit"
                  variant="ghost"
                  className="absolute right-0 top-0 h-full px-4 text-gray-600 hover:text-primary"
                >
                  <Search className="h-5 w-5" />
                </Button>
              </form>
            </div>

            {/* Navigation Icons */}
            <div className="flex items-center space-x-6">
              <Link href="/wishlist" className="text-neutral-dark hover:text-primary relative">
                <Heart className="h-6 w-6" />
                {/* Wishlist count could be dynamic if implemented */}
                <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">0</span>
              </Link>
              
              <Button
                variant="ghost"
                className="text-neutral-dark hover:text-primary relative p-0"
                onClick={() => setIsCartOpen(true)}
              >
                <ShoppingCart className="h-6 w-6" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {cartCount > 99 ? '99+' : cartCount}
                  </span>
                )}
              </Button>
              
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="p-0 text-neutral-dark hover:text-primary">
                      <User className="h-6 w-6" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <div className="px-2 py-1.5 text-sm font-medium">
                      Olá, {user?.name || user?.username}
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/profile">Minha Conta</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/orders">Meus Pedidos</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/wishlist">Lista de Desejos</Link>
                    </DropdownMenuItem>
                    
                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link href="/admin">Painel Admin</Link>
                        </DropdownMenuItem>
                      </>
                    )}
                    
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Logout</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link href="/login" className="text-neutral-dark hover:text-primary">
                  <User className="h-6 w-6" />
                </Link>
              )}
              
              {/* Mobile Menu Button */}
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col h-full">
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-xl font-bold">Menu</span>
                      <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(false)}>
                        <X className="h-6 w-6" />
                      </Button>
                    </div>
                    
                    <form onSubmit={handleSearch} className="mb-6">
                      <div className="relative">
                        <Input
                          type="text"
                          placeholder="Buscar produtos..."
                          className="w-full pr-10"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <Button
                          type="submit"
                          variant="ghost"
                          className="absolute right-0 top-0 h-full px-3"
                        >
                          <Search className="h-5 w-5" />
                        </Button>
                      </div>
                    </form>
                    
                    <div className="flex flex-col space-y-4">
                      <h2 className="text-lg font-semibold">Categorias</h2>
                      <div className="flex flex-col space-y-2">
                        {categories?.map((category: any) => (
                          <Link 
                            key={category.id} 
                            href={`/category/${category.slug}`}
                            className="text-neutral-dark hover:text-primary py-2 border-b border-gray-100"
                            onClick={() => setIsMobileMenuOpen(false)}
                          >
                            {category.name}
                          </Link>
                        ))}
                      </div>
                    </div>
                    
                    <div className="mt-auto pt-6 border-t border-gray-200">
                      {isAuthenticated ? (
                        <div className="space-y-3">
                          <Link 
                            href="/profile"
                            className="flex items-center text-neutral-dark hover:text-primary"
                            onClick={() => setIsMobileMenuOpen(false)}
                          >
                            <User className="mr-2 h-5 w-5" />
                            <span>Minha Conta</span>
                          </Link>
                          
                          <Button 
                            variant="ghost" 
                            className="w-full justify-start p-0 text-neutral-dark hover:text-primary"
                            onClick={() => {
                              handleLogout();
                              setIsMobileMenuOpen(false);
                            }}
                          >
                            <LogOut className="mr-2 h-5 w-5" />
                            <span>Logout</span>
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <Link 
                            href="/login"
                            className="block w-full text-center bg-primary text-white py-2 rounded-lg"
                            onClick={() => setIsMobileMenuOpen(false)}
                          >
                            Login
                          </Link>
                          <Link 
                            href="/register"
                            className="block w-full text-center bg-white border border-primary text-primary py-2 rounded-lg"
                            onClick={() => setIsMobileMenuOpen(false)}
                          >
                            Cadastrar
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Mobile Search */}
          <div className="md:hidden pb-4">
            <form onSubmit={handleSearch} className="relative w-full">
              <Input
                type="text"
                placeholder="Buscar produtos..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Button
                type="submit"
                variant="ghost"
                className="absolute right-0 top-0 h-full px-4 text-gray-600 hover:text-primary"
              >
                <Search className="h-5 w-5" />
              </Button>
            </form>
          </div>

          {/* Categories Navigation */}
          <nav className="border-t border-gray-200 overflow-x-auto scrollbar-hide hidden md:block">
            <ul className="flex space-x-8 py-3 text-sm font-medium">
              <li>
                <Link 
                  href="/" 
                  className={`whitespace-nowrap ${
                    location === '/' 
                      ? 'text-primary border-b-2 border-primary pb-3' 
                      : 'text-neutral-dark hover:text-primary pb-3'
                  }`}
                >
                  Todos
                </Link>
              </li>
              {categories?.map((category: any) => (
                <li key={category.id}>
                  <Link 
                    href={`/category/${category.slug}`} 
                    className={`whitespace-nowrap ${
                      location === `/category/${category.slug}` 
                        ? 'text-primary border-b-2 border-primary pb-3' 
                        : 'text-neutral-dark hover:text-primary pb-3'
                    }`}
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </header>

      {/* Cart Sidebar */}
      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
};

export default Header;
