import { Link, useLocation } from "wouter";
import { Home, Search, ShoppingCart, Heart, User } from "lucide-react";
import { useCart } from "@/lib/cart";

const MobileNavbar = () => {
  const [location] = useLocation();
  const { cartCount } = useCart();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-2 md:hidden z-40">
      <div className="flex justify-around items-center">
        <Link href="/" className={`flex flex-col items-center ${location === '/' ? 'text-primary' : 'text-gray-500 hover:text-primary'}`}>
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">Início</span>
        </Link>

        <Link href="/search" className={`flex flex-col items-center ${location === '/search' ? 'text-primary' : 'text-gray-500 hover:text-primary'}`}>
          <Search className="h-6 w-6" />
          <span className="text-xs mt-1">Buscar</span>
        </Link>

        <Link href="/cart" className={`flex flex-col items-center ${location === '/cart' ? 'text-primary' : 'text-gray-500 hover:text-primary'}`}>
          <div className="relative">
            <ShoppingCart className="h-6 w-6" />
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                {cartCount > 99 ? '99+' : cartCount}
              </span>
            )}
          </div>
          <span className="text-xs mt-1">Carrinho</span>
        </Link>

        <Link href="/wishlist" className={`flex flex-col items-center ${location === '/wishlist' ? 'text-primary' : 'text-gray-500 hover:text-primary'}`}>
          <Heart className="h-6 w-6" />
          <span className="text-xs mt-1">Favoritos</span>
        </Link>

        <Link href="/profile" className={`flex flex-col items-center ${location.startsWith('/profile') ? 'text-primary' : 'text-gray-500 hover:text-primary'}`}>
          <User className="h-6 w-6" />
          <span className="text-xs mt-1">Conta</span>
        </Link>
      </div>
    </div>
  );
};

export default MobileNavbar;
