import { useCart } from "@/lib/cart";
import { X } from "lucide-react";
import CartItem from "./CartItem";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartSidebar = ({ isOpen, onClose }: CartSidebarProps) => {
  const { cartItems, cartTotal, isLoading, clearCart } = useCart();

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-50"
      onClick={onClose}
    >
      <div 
        className="absolute right-0 top-0 bottom-0 bg-white w-full max-w-md shadow-xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h3 className="font-semibold text-lg">
            Seu Carrinho ({cartItems.length} {cartItems.length === 1 ? 'item' : 'itens'})
          </h3>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-500 hover:text-neutral-dark">
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        {isLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : cartItems.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-4">
            <div className="bg-gray-100 rounded-full p-4 mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h4 className="text-lg font-medium mb-2">Seu carrinho está vazio</h4>
            <p className="text-gray-500 text-center mb-4">Adicione alguns produtos para continuar com suas compras</p>
            <Button onClick={onClose} className="bg-primary hover:bg-primary/90 text-white">
              Continuar Comprando
            </Button>
          </div>
        ) : (
          <ScrollArea className="flex-1 overflow-y-auto p-4 space-y-4">
            {cartItems.map((item) => (
              <CartItem key={item.id} item={item} />
            ))}
          </ScrollArea>
        )}
        
        {cartItems.length > 0 && (
          <div className="p-4 border-t border-gray-200">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-semibold">R${cartTotal.toFixed(2).replace('.', ',')}</span>
            </div>
            <div className="flex justify-between mb-4">
              <span className="text-gray-600">Frete</span>
              <span className="font-semibold">R$0,00</span>
            </div>
            <Separator className="my-3" />
            <div className="flex justify-between mb-6 text-lg">
              <span className="font-semibold">Total</span>
              <span className="font-bold">R${cartTotal.toFixed(2).replace('.', ',')}</span>
            </div>
            <Link href="/checkout">
              <Button className="w-full bg-primary hover:bg-primary/90 text-white py-3 mb-3">
                Finalizar Compra
              </Button>
            </Link>
            <Button 
              variant="ghost" 
              className="w-full text-primary hover:underline"
              onClick={onClose}
            >
              Continuar Comprando
            </Button>
            {cartItems.length > 1 && (
              <Button 
                variant="outline" 
                className="w-full mt-2 text-gray-500"
                onClick={() => {
                  if (window.confirm("Tem certeza que deseja limpar o carrinho?")) {
                    clearCart();
                  }
                }}
              >
                Limpar Carrinho
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default CartSidebar;
