import { useState } from "react";
import { Link } from "wouter";
import { Trash2, Plus, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart, CartItem as CartItemType } from "@/lib/cart";

interface CartItemProps {
  item: CartItemType;
}

const CartItem = ({ item }: CartItemProps) => {
  const { updateCartItem, removeFromCart } = useCart();
  const [isUpdating, setIsUpdating] = useState(false);
  const [isRemoving, setIsRemoving] = useState(false);
  
  const handleUpdateQuantity = async (newQuantity: number) => {
    if (newQuantity < 1 || newQuantity > item.product.stock) return;
    
    setIsUpdating(true);
    try {
      await updateCartItem(item.id, newQuantity);
    } catch (error) {
      console.error("Error updating cart item:", error);
    } finally {
      setIsUpdating(false);
    }
  };
  
  const handleRemove = async () => {
    setIsRemoving(true);
    try {
      await removeFromCart(item.id);
    } catch (error) {
      console.error("Error removing cart item:", error);
    } finally {
      setIsRemoving(false);
    }
  };
  
  return (
    <div className="flex items-center space-x-4 bg-gray-50 p-3 rounded-lg mb-3">
      <Link href={`/product/${item.product.id}`}>
        <img 
          src={item.product.imageUrl} 
          alt={item.product.name} 
          className="w-20 h-20 object-cover rounded-md"
          onError={(e) => {
            e.currentTarget.src = "https://via.placeholder.com/80?text=Imagem+Indisponível";
          }}
        />
      </Link>
      <div className="flex-1">
        <Link href={`/product/${item.product.id}`}>
          <h4 className="font-medium hover:text-primary">{item.product.name}</h4>
        </Link>
        <p className="text-gray-500 text-sm">R${item.product.price.toFixed(2).replace('.', ',')}</p>
        <div className="flex items-center mt-2">
          <Button 
            variant="outline" 
            size="icon" 
            className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center p-0"
            onClick={() => handleUpdateQuantity(item.quantity - 1)}
            disabled={isUpdating || item.quantity <= 1}
          >
            <Minus className="h-3 w-3" />
          </Button>
          <span className="mx-2">{item.quantity}</span>
          <Button 
            variant="outline" 
            size="icon" 
            className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center p-0"
            onClick={() => handleUpdateQuantity(item.quantity + 1)}
            disabled={isUpdating || item.quantity >= item.product.stock}
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <Button 
        variant="ghost" 
        size="icon" 
        className="text-gray-400 hover:text-red-500"
        onClick={handleRemove}
        disabled={isRemoving}
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default CartItem;
