import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "./AuthContext";

interface CartItem {
  cartItem: {
    id: number;
    productId: number;
    quantity: number;
  };
  product: {
    id: number;
    name: string;
    price: number;
    image: string;
    slug: string;
  };
}

interface CartContextType {
  cartItems: CartItem[];
  cartTotal: number;
  isCartOpen: boolean;
  isLoading: boolean;
  openCart: () => void;
  closeCart: () => void;
  fetchCart: () => Promise<void>;
  addToCart: (productId: number, quantity?: number) => Promise<void>;
  updateCartItemQuantity: (cartItemId: number, quantity: number) => Promise<void>;
  removeFromCart: (cartItemId: number) => Promise<void>;
  clearCart: () => Promise<void>;
}

const CartContext = createContext<CartContextType>({
  cartItems: [],
  cartTotal: 0,
  isCartOpen: false,
  isLoading: false,
  openCart: () => {},
  closeCart: () => {},
  fetchCart: async () => {},
  addToCart: async () => {},
  updateCartItemQuantity: async () => {},
  removeFromCart: async () => {},
  clearCart: async () => {}
});

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartTotal, setCartTotal] = useState(0);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  
  // Fetch cart data when the component mounts and when user auth state changes
  useEffect(() => {
    if (isAuthenticated) {
      fetchCart();
    } else {
      setCartItems([]);
      setCartTotal(0);
    }
  }, [isAuthenticated]);
  
  // Calculate cart total whenever cart items change
  useEffect(() => {
    const total = cartItems.reduce((sum, item) => {
      return sum + (item.product.price * item.cartItem.quantity);
    }, 0);
    setCartTotal(total);
  }, [cartItems]);
  
  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);
  
  const fetchCart = async () => {
    if (!isAuthenticated) return;
    
    try {
      setIsLoading(true);
      const response = await apiRequest("GET", "/api/cart");
      
      if (response.ok) {
        const data = await response.json();
        setCartItems(data.items || []);
        setCartTotal(data.total || 0);
      }
    } catch (error) {
      console.error("Error fetching cart:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os itens do carrinho.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const addToCart = async (productId: number, quantity: number = 1) => {
    try {
      setIsLoading(true);
      
      // Se não estiver autenticado, armazenar o carrinho no localStorage
      if (!isAuthenticated) {
        // Buscar o produto
        const response = await apiRequest("GET", `/api/products/${productId}`);
        
        if (response.ok) {
          const product = await response.json();
          
          // Criar um item de carrinho local
          const cartItem = {
            cartItem: {
              id: Math.random() * 10000, // ID temporário
              productId: product.id,
              quantity: quantity
            },
            product: {
              id: product.id,
              name: product.name,
              price: product.price,
              image: product.image,
              slug: product.slug
            }
          };
          
          // Adicionar ao estado
          setCartItems(prevItems => [...prevItems, cartItem]);
          
          toast({
            title: "Produto adicionado",
            description: "O produto foi adicionado ao carrinho.",
          });
          
          openCart();
          return;
        } else {
          toast({
            title: "Erro",
            description: "Não foi possível encontrar o produto.",
            variant: "destructive",
          });
          return;
        }
      }
      
      // Se estiver autenticado, usar a API
      const response = await apiRequest("POST", "/api/cart", {
        productId,
        quantity
      });
      
      if (response.ok) {
        // Refresh cart items after adding
        await fetchCart();
        
        toast({
          title: "Produto adicionado",
          description: "O produto foi adicionado ao carrinho.",
        });
        
        openCart();
      } else {
        const errorData = await response.json();
        toast({
          title: "Erro",
          description: errorData.message || "Não foi possível adicionar o produto ao carrinho.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error adding to cart:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao adicionar o produto ao carrinho.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const updateCartItemQuantity = async (cartItemId: number, quantity: number) => {
    try {
      setIsLoading(true);
      
      // Se não estiver autenticado, atualizar o carrinho local
      if (!isAuthenticated) {
        setCartItems(prevItems => 
          prevItems.map(item => 
            item.cartItem.id === cartItemId 
              ? { ...item, cartItem: { ...item.cartItem, quantity } } 
              : item
          )
        );
        return;
      }
      
      // Se estiver autenticado, usar a API
      const response = await apiRequest("PUT", `/api/cart/${cartItemId}`, {
        quantity
      });
      
      if (response.ok) {
        // Refresh cart after update
        await fetchCart();
      } else {
        const errorData = await response.json();
        toast({
          title: "Erro",
          description: errorData.message || "Não foi possível atualizar a quantidade.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error updating cart item:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao atualizar a quantidade.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const removeFromCart = async (cartItemId: number) => {
    if (!isAuthenticated) return;
    
    try {
      setIsLoading(true);
      const response = await apiRequest("DELETE", `/api/cart/${cartItemId}`);
      
      if (response.ok) {
        // Refresh cart after removal
        await fetchCart();
        
        toast({
          title: "Produto removido",
          description: "O produto foi removido do carrinho.",
        });
      } else {
        const errorData = await response.json();
        toast({
          title: "Erro",
          description: errorData.message || "Não foi possível remover o produto do carrinho.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error removing from cart:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao remover o produto do carrinho.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const clearCart = async () => {
    if (!isAuthenticated) return;
    
    try {
      setIsLoading(true);
      const response = await apiRequest("DELETE", "/api/cart");
      
      if (response.ok) {
        setCartItems([]);
        setCartTotal(0);
        
        toast({
          title: "Carrinho limpo",
          description: "Todos os produtos foram removidos do carrinho.",
        });
      } else {
        const errorData = await response.json();
        toast({
          title: "Erro",
          description: errorData.message || "Não foi possível limpar o carrinho.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error clearing cart:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao limpar o carrinho.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <CartContext.Provider
      value={{
        cartItems,
        cartTotal,
        isCartOpen,
        isLoading,
        openCart,
        closeCart,
        fetchCart,
        addToCart,
        updateCartItemQuantity,
        removeFromCart,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  return context;
};
